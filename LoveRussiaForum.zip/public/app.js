let user = null;
let categories = [];
let activeCategory = null;
let activeTopic = null;
let currentPage = 'home';
let siteConfig = { auth: { email: false } };
let notificationUnread = 0;
let authBackendReady = false;
let toastTimer = null;
let currentAdminRoles = [];
let currentPermissionOptions = [];

const $ = (id) => document.getElementById(id);
const escapeHtml = (value = '') => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const formatDate = (value) => {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString('ru-RU', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' });
};
const initials = (value = 'L') => Array.from(String(value).trim())[0]?.toUpperCase() || 'L';
const categoryMap = () => Object.fromEntries(categories.flatMap(group => group.items.map(item => [item.id, item])));
const categoryName = id => categoryMap()[id]?.name || 'Общее';
const hasPermission = permission => user?.role === 'owner' || (user?.permissions || []).includes(permission);

async function apiFetch(url, options = {}) {
  const headers = { ...(options.body && typeof options.body === 'string' ? {'content-type':'application/json'} : {}), ...(options.headers || {}) };
  const response = await fetch(url, { credentials:'same-origin', ...options, headers });
  const type = response.headers.get('content-type') || '';
  const data = type.includes('application/json') ? await response.json().catch(() => ({})) : { error: await response.text().catch(() => '') };
  if (!response.ok) throw new Error(data.error || `Ошибка сервера (${response.status})`);
  return data;
}
function showToast(message) {
  const toast = $('toast');
  $('toastText').textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 4000);
}
function applyProfileAccent(accent = 'red') {
  const colors = {
    red:['#ff2638','#c91f30','#42151b'], green:['#b7f36b','#83c946','#1d3420'],
    blue:['#65b6ff','#3388d1','#17324a'], purple:['#c4a0ff','#9870d8','#32224e'], orange:['#ffad63','#dc7d31','#4a2b16']
  };
  const chosen = colors[accent] || colors.red;
  document.documentElement.style.setProperty('--green', chosen[0]);
  document.documentElement.style.setProperty('--green-2', chosen[1]);
  document.documentElement.style.setProperty('--green-dark', chosen[2]);
}
function updateUserUI() {
  const label = $('loginLabel'), title = $('welcomeTitle'), text = $('welcomeText');
  const side = $('sideLogin'), adminNav = $('adminNav');
  if (user) {
    label.textContent = user.displayName;
    title.textContent = `Добро пожаловать, ${user.displayName}`;
    text.textContent = `${user.roleLabel || 'Игрок'} · ${user.bio || 'Настрой профиль и участвуй в жизни Love Russia.'}`;
    side.textContent = 'Мой профиль ↗';
    document.querySelector('.welcome-avatar').innerHTML = `<img src="${escapeHtml(user.avatarUrl || './assets/love-russia-logo.png?v=7')}" alt="Аватар" onerror="this.src='./assets/love-russia-logo.png?v=7'">`;
    adminNav?.classList.toggle('hidden', !hasPermission('admin.view'));
    $('notificationToggle')?.classList.remove('hidden');
    applyProfileAccent(user.accent);
  } else {
    label.textContent = 'Войти';
    title.innerHTML = 'Новая история<br>начинается здесь';
    text.textContent = 'Войди по email, чтобы участвовать в жизни проекта и общаться с игроками.';
    side.innerHTML = 'Войти в аккаунт <span>↗</span>';
    document.querySelector('.welcome-avatar').innerHTML = '<img src="./assets/love-russia-logo.png?v=7" alt="Love Russia">';
    adminNav?.classList.add('hidden');
    $('notificationToggle')?.classList.add('hidden');
    $('notificationsPanel')?.classList.remove('open');
    applyProfileAccent('red');
  }
}

async function loadCategories() {
  const data = await apiFetch('/api/categories');
  categories = data.groups || [];
  return categories;
}
async function refreshStats() {
  try {
    const stats = await apiFetch('/api/stats');
    $('statMembers').textContent = Number(stats.members || 0).toLocaleString('ru-RU');
    $('statTopics').textContent = Number(stats.topics || 0).toLocaleString('ru-RU');
    $('statOnline').textContent = Number(stats.online || 0).toLocaleString('ru-RU');
    $('onlineMemberCount').textContent = `${Number(stats.online || 0)} ${plural(stats.online || 0, 'участник', 'участника', 'участников')}`;
    $('onlineHeaderStatus').innerHTML = '<i></i> LIVE';
    $('lastRegistered').textContent = stats.lastRegistered || 'Пока нет';
    const avatarStack = document.querySelector('.avatar-stack');
    if (avatarStack) {
      const activeUsers = Array.isArray(stats.onlineUsers) ? stats.onlineUsers : [];
      avatarStack.innerHTML = activeUsers.map(person => `<span class="avatar" title="${escapeHtml(person.displayName)}">${person.avatarUrl ? `<img src="${escapeHtml(person.avatarUrl)}" alt="" loading="lazy">` : escapeHtml(initials(person.displayName))}</span>`).join('');
      avatarStack.classList.toggle('has-users', activeUsers.length > 0);
      avatarStack.setAttribute('aria-label', activeUsers.length ? `Сейчас онлайн: ${activeUsers.map(person=>person.displayName).join(', ')}` : 'Нет активных пользователей');
    }
  } catch (error) {
    $('statMembers').textContent = '—'; $('statTopics').textContent = '—'; $('statOnline').textContent = '—';
    $('onlineMemberCount').textContent = 'Нет данных'; $('onlineHeaderStatus').textContent = 'НЕТ СВЯЗИ';
    $('lastRegistered').textContent = 'Нет связи с сервером';
    const avatarStack = document.querySelector('.avatar-stack');
    if (avatarStack) avatarStack.replaceChildren();
  }
}
function plural(number, one, few, many) {
  const n = Math.abs(Number(number)) % 100, n1 = n % 10;
  if (n > 10 && n < 20) return many;
  if (n1 > 1 && n1 < 5) return few;
  if (n1 === 1) return one;
  return many;
}

async function renderHome() {
  activeCategory = null; activeTopic = null; currentPage = 'home';
  $('contentTitle').textContent = 'Разделы форума';
  $('allTopicsButton').classList.remove('hidden');
  const host = $('mainView');
  host.innerHTML = '<div class="empty-state">Загружаем реальные разделы форума…</div>';
  try {
    await loadCategories();
    host.innerHTML = categories.length ? categories.map(group => `
      <section class="category-group">
        <div class="group-heading"><span class="group-icon">${escapeHtml(group.icon)}</span><h3>${escapeHtml(group.title)}</h3><span class="group-line"></span><small>${escapeHtml(group.note)}</small></div>
        <div class="category-grid">${group.items.map(cat => `
          <button class="category-card" data-category="${escapeHtml(cat.id)}">
            <span class="category-symbol">${escapeHtml(cat.icon)}</span>
            <span class="category-info"><strong>${escapeHtml(cat.name)}</strong><p>${escapeHtml(cat.description)}</p>
              <span class="category-meta"><span><b>${cat.topics}</b> тем</span><span><b>${cat.posts}</b> сообщений</span></span>
            </span>
          </button>`).join('')}
        </div>
      </section>`).join('') : '<div class="empty-state">Разделы ещё не созданы.</div>';
    host.querySelectorAll('[data-category]').forEach(el => el.addEventListener('click', () => renderCategory(el.dataset.category)));
    await renderLatest();
  } catch (error) { host.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
async function renderLatest() {
  const host = $('latestTopics');
  try {
    const data = await apiFetch('/api/latest-topics');
    const latest = data.topics || [];
    host.innerHTML = latest.length ? latest.map((topic, index) => `
      <div class="latest-item" data-topic="${topic.id}"><span class="latest-bullet">${['↗','✳','▤','◈'][index % 4]}</span>
        <span><strong>${escapeHtml(topic.title)}</strong><small>${escapeHtml(topic.author)} · ${formatDate(topic.created)}</small></span></div>`).join('')
      : '<div class="empty-state compact-empty">Пока нет опубликованных тем. Будь первым!</div>';
    host.querySelectorAll('[data-topic]').forEach(el => el.addEventListener('click', () => renderTopic(Number(el.dataset.topic))));
  } catch { host.innerHTML = '<div class="empty-state compact-empty">Не удалось загрузить обсуждения.</div>'; }
}
async function renderCategory(id) {
  const cat = categoryMap()[id]; if (!cat) return;
  activeCategory = id; activeTopic = null; currentPage = 'category';
  $('contentTitle').textContent = cat.name; $('allTopicsButton').classList.add('hidden');
  const host = $('mainView'); host.innerHTML = '<div class="empty-state">Загружаем темы…</div>';
  try {
    const data = await apiFetch(`/api/topics?category=${encodeURIComponent(id)}`);
    const list = data.topics || [];
    host.innerHTML = `<button class="back-link" id="backHome"><span>←</span> Все разделы форума</button>
      <div class="view-banner"><span class="category-symbol">${escapeHtml(cat.icon)}</span><div><h3>${escapeHtml(cat.name)}</h3><p>${escapeHtml(cat.description)}</p></div></div>
      <div class="view-tools"><span>${list.length} тем · ${list.reduce((sum,t)=>sum+1+t.replies,0)} сообщений</span><button class="small-primary" id="categoryCreate">＋ Создать тему</button></div>
      <div class="topic-list">${list.length ? list.map(topicRow).join('') : '<div class="empty-state">В этом разделе пока нет тем. Создай первую!</div>'}</div>`;
    $('backHome').onclick = renderHome; $('categoryCreate').onclick = () => openTopicModal(id);
    host.querySelectorAll('[data-topic]').forEach(el => el.addEventListener('click', () => renderTopic(Number(el.dataset.topic))));
  } catch (error) { host.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
function topicRow(topic) {
  return `<div class="topic-row" data-topic="${topic.id}"><div class="topic-avatar">${escapeHtml(initials(topic.author))}</div>
    <div class="topic-main"><strong>${escapeHtml(topic.title)}</strong><p>${escapeHtml(topic.author)} · ${formatDate(topic.created)} · ${escapeHtml(topic.categoryName || categoryName(topic.cat))}</p>
      ${topic.pinned ? '<span class="tag">ЗАКРЕПЛЕНО</span>' : ''}${topic.locked ? '<span class="tag">ЗАКРЫТО</span>' : ''}</div>
    <div class="topic-side"><strong>${topic.replies || 0} ответов</strong>${Number(topic.views || 0).toLocaleString('ru-RU')} просмотров</div></div>`;
}
async function renderTopic(id) {
  activeTopic = id; currentPage = 'topic'; $('contentTitle').textContent = 'Обсуждение'; $('allTopicsButton').classList.add('hidden');
  const host = $('mainView'); host.innerHTML = '<div class="empty-state">Загружаем тему…</div>';
  try {
    const data = await apiFetch(`/api/topics/${id}`); const topic = data.topic; const replies = data.replies || [];
    activeCategory = topic.cat;
    const moderation = hasPermission('forum.moderate') ? `<div class="thread-actions admin-thread-actions">
      <button class="reaction-button" id="pinTopic">${topic.pinned ? 'Открепить' : 'Закрепить'}</button>
      <button class="reaction-button" id="lockTopic">${topic.locked ? 'Открыть ответы' : 'Закрыть ответы'}</button>
      ${hasPermission('forum.delete') ? '<button class="reaction-button danger-action" id="deleteTopic">Удалить тему</button>' : ''}</div>` : '';
    host.innerHTML = `<button class="back-link" id="backCategory"><span>←</span> ${escapeHtml(categoryName(topic.cat))}</button>
      <article class="thread-card"><header class="thread-head"><div class="section-kicker">${escapeHtml(categoryName(topic.cat).toUpperCase())}${topic.pinned ? ' · ЗАКРЕПЛЁННАЯ ТЕМА' : ''}</div>
        <h2>${escapeHtml(topic.title)}</h2><div class="thread-meta">Автор: <b>${escapeHtml(topic.author)}</b> · ${formatDate(topic.created)} · ${topic.views} просмотров</div></header>
        <div class="thread-body">${escapeHtml(topic.body).replace(/\n/g,'<br>')}</div>
        <div class="thread-actions"><button class="reaction-button ${topic.liked ? 'liked' : ''}" id="likeButton">♥ ${topic.likes || 0} · Нравится</button><button class="reaction-button" id="copyTopic">↗ Скопировать ссылку</button></div>
        ${moderation}</article>
      <h3 class="replies-heading">Ответы · ${replies.length}</h3>
      <div id="replyList">${replies.length ? replies.map(reply => `<div class="reply-card"><div class="reply-top"><span>${escapeHtml(reply.author)} <small>${escapeHtml(reply.role)}</small></span><small>${formatDate(reply.created)}</small></div><p>${escapeHtml(reply.body).replace(/\n/g,'<br>')}</p></div>`).join('') : '<div class="empty-state">Пока нет ответов. Начни обсуждение.</div>'}</div>
      ${topic.locked && !hasPermission('forum.moderate') ? '<div class="empty-state">Тема закрыта для новых ответов.</div>' : `<form class="reply-form" id="replyForm"><textarea id="replyText" required maxlength="4000" placeholder="Напиши ответ в теме..."></textarea><button class="small-primary" type="submit">Отправить ответ ↗</button></form>`}`;
    $('backCategory').onclick = () => renderCategory(topic.cat);
    $('likeButton').onclick = async () => { if (!ensureUser()) return; try { await apiFetch(`/api/topics/${id}/like`,{method:'POST'}); await renderTopic(id); } catch(error) { showToast(error.message); } };
    $('copyTopic').onclick = async () => { try { await navigator.clipboard.writeText(`${location.origin}/#topic-${id}`); showToast('Ссылка скопирована'); } catch { showToast('Не удалось скопировать ссылку'); } };
    $('replyForm')?.addEventListener('submit', async event => {
      event.preventDefault(); if (!ensureUser()) return;
      const body = $('replyText').value.trim(); if (!body) return;
      try { await apiFetch(`/api/topics/${id}/replies`,{method:'POST',body:JSON.stringify({body})}); await renderTopic(id); await refreshStats(); await renderLatest(); showToast('Ответ опубликован'); }
      catch(error) { showToast(error.message); }
    });
    $('pinTopic')?.addEventListener('click', async () => { try { await apiFetch(`/api/topics/${id}/moderate`,{method:'POST',body:JSON.stringify({pinned:!topic.pinned})}); await renderTopic(id); } catch(error) { showToast(error.message); } });
    $('lockTopic')?.addEventListener('click', async () => { try { await apiFetch(`/api/topics/${id}/moderate`,{method:'POST',body:JSON.stringify({locked:!topic.locked})}); await renderTopic(id); } catch(error) { showToast(error.message); } });
    $('deleteTopic')?.addEventListener('click', async () => { if (!confirm('Удалить тему и все ответы?')) return; try { await apiFetch(`/api/topics/${id}`,{method:'DELETE'}); showToast('Тема удалена'); await refreshStats(); await renderLatest(); await renderCategory(topic.cat); } catch(error) { showToast(error.message); } });
  } catch (error) { host.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
async function renderAllTopics(query = '') {
  currentPage = 'all'; activeCategory = null; activeTopic = null;
  $('contentTitle').textContent = query ? 'Результаты поиска' : 'Все темы'; $('allTopicsButton').classList.add('hidden');
  const host = $('mainView'); host.innerHTML = '<div class="empty-state">Загружаем темы…</div>';
  try {
    const data = await apiFetch(`/api/topics${query ? `?q=${encodeURIComponent(query)}` : ''}`); const list = data.topics || [];
    host.innerHTML = `<button class="back-link" id="backHome"><span>←</span> Все разделы форума</button><div class="view-tools"><span>Найдено тем: ${list.length}</span><button class="small-primary" id="allCreate">＋ Создать тему</button></div>
      <div class="topic-list">${list.length ? list.map(topicRow).join('') : `<div class="empty-state">${query ? 'По запросу ничего не найдено.' : 'Тем пока нет.'}</div>`}</div>`;
    $('backHome').onclick = renderHome; $('allCreate').onclick = () => openTopicModal();
    host.querySelectorAll('[data-topic]').forEach(el => el.addEventListener('click', () => renderTopic(Number(el.dataset.topic))));
  } catch(error) { host.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
function renderRules() {
  currentPage = 'rules'; activeTopic = null; activeCategory = null; $('contentTitle').textContent = 'Правила сообщества'; $('allTopicsButton').classList.add('hidden');
  $('mainView').innerHTML = `<div class="info-panel"><div class="section-kicker">01 / ОСНОВА СООБЩЕСТВА</div><h3>Уважай других игроков</h3><p>Love Russia — пространство для совместной ролевой игры. Общайся спокойно и уважай других участников.</p></div>
    <div class="info-panel"><div class="section-kicker">02 / ФОРУМ</div><h3>Публикации и обсуждения</h3><ul><li>Выбирай подходящий раздел.</li><li>Используй понятные заголовки.</li><li>Не публикуй личные данные других игроков.</li><li>Не размещай спам и заведомо ложные сведения.</li></ul></div>
    <div class="info-panel"><div class="section-kicker">03 / ROLEPLAY</div><h3>Играй честно</h3><p>Соблюдай правила сервера, не выдавай внеигровую информацию за игровую и не используй форум для травли.</p></div>
    <div class="info-panel"><div class="section-kicker">04 / МОДЕРАЦИЯ</div><h3>Решения администрации</h3><p>Модераторы могут переносить, закрывать и удалять публикации, нарушающие правила проекта.</p></div>`;
}
async function renderTeam() {
  currentPage = 'team'; activeTopic = null; activeCategory = null; $('contentTitle').textContent = 'Команда проекта'; $('allTopicsButton').classList.add('hidden');
  const host = $('mainView'); host.innerHTML = '<div class="empty-state">Загружаем команду…</div>';
  try {
    const data = await apiFetch('/api/team');
    host.innerHTML = `<div class="view-banner"><span class="category-symbol">✳</span><div><h3>Команда Love Russia</h3><p>Список формируется автоматически на основе реальных ролей пользователей.</p></div></div>
      <div class="staff-grid">${data.team.length ? data.team.map(member => `<div class="staff-card">${member.avatarUrl ? `<img class="staff-avatar-img" src="${escapeHtml(member.avatarUrl)}" alt="">` : `<span class="staff-avatar">${escapeHtml(initials(member.displayName))}</span>`}<span><strong>${escapeHtml(member.displayName)}</strong><small style="color:${escapeHtml(member.roleColor)}">${escapeHtml(member.roleLabel)}</small></span></div>`).join('') : '<div class="empty-state">Состав команды пока пуст. Здесь появятся пользователи, которым назначены роли.</div>'}</div>`;
  } catch(error) { host.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
async function renderServers() {
  currentPage = 'servers'; activeTopic = null; activeCategory = null; $('contentTitle').textContent = 'Игровые серверы'; $('allTopicsButton').classList.add('hidden');
  const host = $('mainView'); host.innerHTML = '<div class="empty-state">Проверяем источник статуса…</div>';
  try {
    const data = await apiFetch('/api/servers');
    host.innerHTML = `<div class="view-banner"><span class="category-symbol">◎</span><div><h3>Игровые серверы Love Russia</h3><p>Показываем только данные из подключённого источника статуса.</p></div></div>
      ${data.servers?.length ? data.servers.map(server => `<div class="info-panel"><div class="side-heading"><h3>${escapeHtml(server.name)}</h3><span class="server-live"><i></i>${server.online?'ONLINE':'OFFLINE'}</span></div><p>Игроков: ${server.players} / ${server.maxPlayers || '—'} ${server.map ? `· Карта: ${escapeHtml(server.map)}` : ''}</p>${server.maxPlayers ? `<div class="server-meter"><span style="width:${Math.min(100,server.players/server.maxPlayers*100)}%"></span></div>` : ''}</div>`).join('') : `<div class="info-panel"><div class="section-kicker">СТАТУС НЕ ПОДКЛЮЧЁН</div><h3>${escapeHtml(data.message || 'Нет данных об игровых серверах.')}</h3><p>Пока у проекта нет подключённого API статуса игры, форум не будет показывать выдуманные онлайн-цифры. Когда появится API, его адрес можно добавить в GAME_STATUS_API_URL.</p></div>`}`;
  } catch(error) { host.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`; }
}
function setPage(page) {
  document.querySelectorAll('.nav-link').forEach(el => el.classList.toggle('active', el.dataset.page === page));
  document.querySelector('.main-nav')?.classList.remove('open');
  if(page==='home') void renderHome(); if(page==='rules') renderRules(); if(page==='team') void renderTeam(); if(page==='servers') void renderServers(); if(page==='admin') void renderAdmin();
  $('forumContent').scrollIntoView({behavior:'smooth',block:'start'});
}
function ensureUser() { if(user) return true; openModal('login'); showToast('Сначала войди в аккаунт'); return false; }
function openModal(mode='topic', category=null) {
  const backdrop=$('modalBackdrop'),topicFields=$('topicFields'),loginFields=$('loginFields'),form=$('modalForm');
  $('modalKicker').textContent=mode==='login'?'LOVE ID':'LOVE RUSSIA COMMUNITY';
  $('modalTitle').textContent=mode==='login'?'Войти или зарегистрироваться':'Создать новую тему';
  $('modalDescription').textContent=mode==='login'?'Введи email. Мы отправим код подтверждения — он подойдёт и для входа, и для регистрации.':'Поделись новостью, задай вопрос или начни обсуждение.';
  topicFields.classList.toggle('hidden',mode!=='topic'); loginFields.classList.toggle('hidden',mode!=='login'); $('modalSubmit').classList.toggle('hidden',mode==='login'); $('emailAuthEmail').required=mode==='login';
  $('modalSubmit').innerHTML='Опубликовать тему <span class="button-arrow">↗</span>';
  const select=$('topicCategory');select.innerHTML=categories.map(group=>`<optgroup label="${escapeHtml(group.title)}">${group.items.map(cat=>`<option value="${escapeHtml(cat.id)}">${escapeHtml(cat.name)}</option>`).join('')}</optgroup>`).join('');
  if(category)select.value=category;
  form.dataset.mode=mode; backdrop.classList.add('open'); backdrop.setAttribute('aria-hidden','false');
  if(mode==='login') { $('emailCodeBlock').classList.add('hidden'); $('emailAuthCode').value=''; $('authSetupNote').textContent='Введи email — мы отправим шестизначный код. Проверь также папку «Спам».'; void refreshAuthAvailability(); }
}
function closeModal() { $('modalBackdrop').classList.remove('open'); $('modalBackdrop').setAttribute('aria-hidden','true'); }
function openTopicModal(category) { if(ensureUser()) openModal('topic',category); }

$('modalForm').addEventListener('submit',async event=>{
  event.preventDefault(); if(event.currentTarget.dataset.mode==='login')return; if(!ensureUser())return;
  const title=$('topicTitle').value.trim(),body=$('topicBody').value.trim(),category=$('topicCategory').value;
  if(title.length<5||body.length<8){showToast('Добавь заголовок и более подробное сообщение');return;}
  try { const result=await apiFetch('/api/topics',{method:'POST',body:JSON.stringify({category,title,body})}); closeModal(); $('topicTitle').value=''; $('topicBody').value=''; await refreshStats(); await renderLatest(); await renderTopic(result.id); showToast('Тема опубликована на сервере'); }
  catch(error){showToast(error.message);}
});
$('modalClose').onclick=closeModal;
$('modalBackdrop').addEventListener('click',event=>{if(event.target.id==='modalBackdrop')closeModal();});
document.querySelectorAll('.nav-link').forEach(el=>el.addEventListener('click',()=>setPage(el.dataset.page)));
$('heroCreate').onclick=()=>openTopicModal(); $('bottomCreate').onclick=()=>openTopicModal(); $('browseForum').onclick=()=>$('forumContent').scrollIntoView({behavior:'smooth'});
$('allTopicsButton').onclick=()=>void renderAllTopics();
$('loginButton').onclick=()=>user?openProfile():openModal('login'); $('sideLogin').onclick=()=>user?openProfile():openModal('login');
$('mobileMenu').onclick=()=>document.querySelector('.main-nav').classList.toggle('open');

const searchPanel=$('searchPanel');
function openSearch(){searchPanel.classList.add('open');searchPanel.setAttribute('aria-hidden','false');setTimeout(()=>$('searchInput').focus(),80);}
function closeSearch(){searchPanel.classList.remove('open');searchPanel.setAttribute('aria-hidden','true');}
$('searchToggle').onclick=openSearch; $('searchClose').onclick=closeSearch;
$('searchInput').addEventListener('keydown',event=>{if(event.key==='Enter'){const query=event.target.value.trim();closeSearch();void renderAllTopics(query);$('forumContent').scrollIntoView({behavior:'smooth'});}});
document.addEventListener('keydown',event=>{if(event.key==='Escape'){closeModal();closeProfile();closeSearch();}});

// Email authentication: one-time code is sent by the server over SMTP.
async function refreshAuthAvailability(){
  const note=$('authSetupNote');
  try{
    const config=await apiFetch('/api/config');
    siteConfig=config;
    authBackendReady=true;
    if(note && !config.auth?.email) note.textContent='Отправка писем ещё не настроена. Администратору нужно добавить SMTP_HOST, SMTP_USER и SMTP_PASS в .env.';
    return true;
  }catch(error){
    authBackendReady=false;
    if(note){
      const localHost=['localhost','127.0.0.1'].includes(location.hostname);
      note.textContent=localHost
        ?'Backend не отвечает. Запусти npm start в папке LoveRussiaForum и открой http://localhost:3000.'
        :'Сервер форума недоступен. Проверь подключение backend.';
    }
    return false;
  }
}
$('emailSendCode').onclick=async()=>{
  const email=$('emailAuthEmail').value.trim().toLowerCase();
  if(!email){showToast('Введи email');$('emailAuthEmail').focus();return;}
  const button=$('emailSendCode');button.disabled=true;button.textContent='Отправляем…';
  try{
    const result=await apiFetch('/api/auth/email/request',{method:'POST',body:JSON.stringify({email})});
    $('emailCodeBlock').classList.remove('hidden');$('authSetupNote').textContent=result.message||'Код отправлен. Проверь почту и папку «Спам».';$('emailAuthCode').focus();showToast('Код отправлен на почту');
  }catch(error){$('authSetupNote').textContent=error.message;showToast(error.message);}
  finally{button.disabled=false;button.innerHTML='Отправить код повторно <span class="button-arrow">↗</span>';}
};
$('emailVerifyCode').onclick=async()=>{
  const email=$('emailAuthEmail').value.trim().toLowerCase(),code=$('emailAuthCode').value.trim(),displayName=$('emailAuthName').value.trim();
  if(!/^\d{6}$/.test(code)){showToast('Введи шестизначный код из письма');return;}
  const button=$('emailVerifyCode');button.disabled=true;button.textContent='Проверяем…';
  try{
    const result=await apiFetch('/api/auth/email/verify',{method:'POST',body:JSON.stringify({email,code,displayName})});
    user=result.user;updateUserUI();closeModal();await presenceHeartbeat();await refreshStats();await refreshNotifications();
    showToast(user.role==='owner'?'Добро пожаловать, владелец Love Russia!':'Вход выполнен. Добро пожаловать в Love Russia!');
  }catch(error){$('authSetupNote').textContent=error.message;showToast(error.message);}
  finally{button.disabled=false;button.innerHTML='Подтвердить и войти <span class="button-arrow">↗</span>';}
};
async function syncCurrentUser(){try{const data=await apiFetch('/api/me');user=data.user||null;updateUserUI();if(user)await presenceHeartbeat();}catch{user=null;updateUserUI();}}
async function presenceHeartbeat(){if(!user)return;try{await apiFetch('/api/presence',{method:'POST'});}catch(error){if(error.message.includes('Сначала войди')){user=null;updateUserUI();}}}

// Profile editor.
function openProfile(){
  if(!user){openModal('login');return;}
  $('profileDisplayName').value=user.displayName||'';$('profileBio').value=user.bio||'';$('profileSignature').value=user.signature||'';$('profileAvatar').value=user.avatarUrl||'';$('profileAccent').value=user.accent||'red';
  $('profilePreview').src=user.avatarUrl||'./assets/love-russia-logo.png?v=7';$('profileRole').textContent=user.roleLabel||'Игрок';
  $('profileEmail').textContent=`${user.email||'Email не указан'} · ${user.emailVerifiedAt?'подтверждён':'не подтверждён'}`;
  $('profileEmailNotifications').checked=Boolean(user.emailNotifications);
  $('profileBackdrop').classList.add('open');$('profileBackdrop').setAttribute('aria-hidden','false');
}
function closeProfile(){$('profileBackdrop').classList.remove('open');$('profileBackdrop').setAttribute('aria-hidden','true');}
$('profileAvatar').addEventListener('input',event=>{const value=event.target.value.trim();$('profilePreview').src=/^https:\/\//i.test(value)?value:'./assets/love-russia-logo.png?v=7';});
$('profileForm').addEventListener('submit',async event=>{
  event.preventDefault();try{const result=await apiFetch('/api/profile',{method:'PUT',body:JSON.stringify({displayName:$('profileDisplayName').value,bio:$('profileBio').value,signature:$('profileSignature').value,avatarUrl:$('profileAvatar').value,accent:$('profileAccent').value,emailNotifications:$('profileEmailNotifications').checked})});user=result.user;updateUserUI();closeProfile();showToast('Профиль сохранён');}catch(error){showToast(error.message);}
});
$('profileClose').onclick=closeProfile;$('profileBackdrop').addEventListener('click',event=>{if(event.target.id==='profileBackdrop')closeProfile();});
$('logoutButton').onclick=async()=>{try{await apiFetch('/api/logout',{method:'POST'});user=null;updateUserUI();closeProfile();showToast('Ты вышел из аккаунта');await refreshStats();}catch(error){showToast(error.message);}};

// In-app notification center. Each item is persisted in SQLite on the server.
function notificationIcon(type){return ({reply:'↩',like:'♥',role:'★',moderation:'!',announcement:'✦',welcome:'✳'})[type]||'•';}
async function refreshNotifications(){
  if(!user){notificationUnread=0;return;}
  try{
    const data=await apiFetch('/api/notifications');notificationUnread=Number(data.unread||0);
    const badge=$('notificationBadge');badge.textContent=notificationUnread>99?'99+':String(notificationUnread);badge.classList.toggle('hidden',notificationUnread===0);
    $('notificationsSummary').textContent=notificationUnread?`${notificationUnread} непрочитанных`:'Все уведомления прочитаны';
    const list=$('notificationsList');
    list.innerHTML=data.notifications?.length?data.notifications.map(item=>`<button type="button" class="notification-item ${item.read_at?'':'unread'}" data-notification-id="${item.id}" data-notification-link="${escapeHtml(item.link||'/')}"><span class="notification-icon">${notificationIcon(item.type)}</span><span class="notification-copy"><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.body)}</span><small>${formatDate(item.created_at)}</small></span></button>`).join(''):'<div class="empty-state compact-empty">Уведомлений пока нет.</div>';
    list.querySelectorAll('[data-notification-id]').forEach(button=>button.onclick=async()=>{
      try{await apiFetch(`/api/notifications/${button.dataset.notificationId}/read`,{method:'POST'});}catch{}
      const link=button.dataset.notificationLink||'/';$('notificationsPanel').classList.remove('open');$('notificationsPanel').setAttribute('aria-hidden','true');
      if(link.startsWith('/#topic-')){location.href=link;}else if(link==='/'){$('forumContent').scrollIntoView({behavior:'smooth'});}
      await refreshNotifications();
    });
  }catch(error){console.warn('[notifications]',error.message);}
}
$('notificationToggle').onclick=async()=>{
  if(!user){openModal('login');return;}
  const panel=$('notificationsPanel');const opening=!panel.classList.contains('open');panel.classList.toggle('open',opening);panel.setAttribute('aria-hidden',opening?'false':'true');if(opening)await refreshNotifications();
};
$('notificationsReadAll').onclick=async()=>{
  try{await apiFetch('/api/notifications/read-all',{method:'POST'});await refreshNotifications();showToast('Все уведомления прочитаны');}catch(error){showToast(error.message);}
};
document.addEventListener('click',event=>{
  if(!$('notificationsPanel')?.contains(event.target)&&!$('notificationToggle')?.contains(event.target)){$('notificationsPanel')?.classList.remove('open');$('notificationsPanel')?.setAttribute('aria-hidden','true');}
});

// Live server status panel: no hard-coded population values.
async function refreshSidebarServers(){
  try{
    const data=await apiFetch('/api/servers');const host=$('serverSummary');const header=$('serverHeaderStatus');
    if(!data.servers?.length){if(header)header.textContent='— НЕТ ДАННЫХ';host.innerHTML=`<div class="empty-state compact-empty">${escapeHtml(data.message||'Нет данных об игровых серверах.')}</div>`;return;}
    const anyOnline=data.servers.some(server=>server.online);
    if(header)header.innerHTML=`<i></i> ${anyOnline?'ONLINE':'OFFLINE'}`;
    host.innerHTML=data.servers.map(server=>`<div class="server-row"><span class="server-name"><i class="status-dot" style="background:${server.online?'#66df8b':'#e36d72'}"></i>${escapeHtml(server.name)}</span><strong>${Number(server.players).toLocaleString('ru-RU')} / ${server.maxPlayers?Number(server.maxPlayers).toLocaleString('ru-RU'):'—'}</strong></div>${server.maxPlayers?`<div class="server-meter"><span style="width:${Math.min(100,server.players/server.maxPlayers*100)}%"></span></div>`:''}`).join('');
  }catch{const header=$('serverHeaderStatus');if(header)header.textContent='— ОШИБКА';$('serverSummary').innerHTML='<div class="empty-state compact-empty">Не удалось получить статус.</div>';}
}

// Owner dashboard: users, roles, permission assignment and audit log.
async function renderAdmin(){
  currentPage='admin';activeTopic=null;activeCategory=null;$('contentTitle').textContent='Панель управления';$('allTopicsButton').classList.add('hidden');
  const host=$('mainView');host.innerHTML='<div class="empty-state">Загружаем панель управления…</div>';
  try{
    const overview=await apiFetch('/api/admin/overview');
    const [usersData,roleData,roleAdminData]=await Promise.all([
      hasPermission('users.view')?apiFetch('/api/admin/users'):Promise.resolve({users:[]}),
      hasPermission('users.assign_role')?apiFetch('/api/roles'):Promise.resolve({roles:[]}),
      user?.role==='owner'?apiFetch('/api/admin/roles'):Promise.resolve({roles:[],permissionOptions:[]})
    ]);
    currentAdminRoles=roleAdminData.roles?.length?roleAdminData.roles:(roleData.roles||[]);
    currentPermissionOptions=roleAdminData.permissionOptions||[];
    host.innerHTML=`<div class="view-banner"><span class="category-symbol">⌘</span><div><h3>Управление Love Russia</h3><p>Показатели рассчитаны по реальным аккаунтам, темам и ответам в SQLite.</p></div></div>
      <div class="admin-metrics"><div class="admin-metric"><strong>${overview.members}</strong><small>АККАУНТОВ</small></div><div class="admin-metric"><strong>${overview.online}</strong><small>ОНЛАЙН ЗА 90 СЕК.</small></div><div class="admin-metric"><strong>${overview.topics}</strong><small>ТЕМ</small></div><div class="admin-metric"><strong>${overview.posts}</strong><small>СООБЩЕНИЙ</small></div></div>
      <div class="admin-note">Регистрация по email: ${overview.emailReady?'SMTP подключён':'SMTP не настроен — добавь SMTP-параметры в .env'} · API игровых серверов: ${overview.gameApiReady?'подключён':'не подключён'}.</div>
      ${user?.role==='owner'?renderRoleManagerMarkup():''}
      ${user?.role==='owner'?'<section class="info-panel broadcast-panel"><div class="section-kicker">ОБЪЯВЛЕНИЕ СООБЩЕСТВУ</div><h3>Разослать уведомление всем игрокам</h3><form id="broadcastForm"><label>Заголовок<input id="broadcastTitle" maxlength="100" required placeholder="Например: Технические работы"></label><label>Текст<textarea id="broadcastBody" maxlength="1000" required rows="3" placeholder="Сообщение для всех пользователей форума"></textarea></label><button class="small-primary" type="submit">Отправить уведомление</button></form><small class="broadcast-hint">Уведомление появится в колокольчике у всех зарегистрированных аккаунтов. Массовые письма не отправляются.</small></section>':''}
      ${hasPermission('users.view')?`<div class="section-heading admin-section-heading"><div><div class="section-kicker">АККАУНТЫ</div><h2>Пользователи</h2></div></div><input class="admin-search" id="adminSearch" placeholder="Поиск по игровому нику..."><div class="admin-user-list" id="adminUserList">${adminUsersMarkup(usersData.users||[])}</div>`:''}
      ${user?.role==='owner'?'<div id="auditPanel" class="info-panel admin-audit"><div class="section-kicker">ЖУРНАЛ ДЕЙСТВИЙ</div><h3>Последние действия администрации</h3><div id="auditList" class="empty-state">Загружаем журнал…</div></div>':''}`;
    $('adminSearch')?.addEventListener('input',async event=>{try{const data=await apiFetch(`/api/admin/users?q=${encodeURIComponent(event.target.value)}`);$('adminUserList').innerHTML=adminUsersMarkup(data.users);wireAdminActions();}catch(error){showToast(error.message);}});
    wireAdminActions();wireRoleManager();wireAudit();wireBroadcast();
  }catch(error){host.innerHTML=`<div class="empty-state">${escapeHtml(error.message)}</div>`;}
}
function adminUsersMarkup(users){
  if(!users.length)return '<div class="empty-state">Пока нет зарегистрированных аккаунтов. После подтверждения email они появятся здесь.</div>';
  return users.map(item=>`<div class="admin-user"><img class="admin-user-avatar" src="${escapeHtml(item.avatarUrl||'./assets/love-russia-logo.png?v=7')}" alt=""><div class="admin-user-main"><strong>${escapeHtml(item.displayName)}</strong><small>ID #${item.id} · ${escapeHtml(item.email||'email не указан')} · регистрация ${formatDate(item.createdAt)}</small></div>
    <span class="role-pill" style="color:${escapeHtml(item.roleColor||'#9aa4ad')}">${escapeHtml(item.roleLabel)}</span>
    ${hasPermission('users.assign_role')&&item.role!=='owner'?`<select class="role-select" data-role-select="${item.id}">${currentAdminRoles.filter(role=>role.key!=='owner'&&(user?.role==='owner'||role.rank<(currentAdminRoles.find(candidate=>candidate.key===user?.role)?.rank??0))).map(role=>`<option value="${escapeHtml(role.key)}" ${role.key===item.role?'selected':''}>${escapeHtml(role.label)}</option>`).join('')}</select><button class="small-ban" data-assign-role="${item.id}">Роль</button>`:''}
    ${hasPermission('users.ban')&&item.role!=='owner'?(item.bannedUntil&&item.bannedUntil>Date.now()?`<button class="small-ban" data-unban-user="${item.id}">Снять бан</button>`:`<button class="small-ban" data-ban-user="${item.id}">Бан 1 ч</button>`):''}</div>`).join('');
}
function renderRoleManagerMarkup(){
  const checks=currentPermissionOptions.map(permission=>`<label class="permission-option"><input type="checkbox" value="${escapeHtml(permission.key)}"><span>${escapeHtml(permission.label)}</span></label>`).join('');
  return `<section class="role-manager" id="roleManager"><div class="section-heading admin-section-heading"><div><div class="section-kicker">КОНСТРУКТОР ДОСТУПА</div><h2>Роли и разрешения</h2></div><span class="role-count">${currentAdminRoles.length} ролей</span></div>
    <form id="roleForm" class="role-form"><input type="hidden" id="roleEditId"><div class="role-form-grid"><label>Название роли<input id="roleLabelInput" required maxlength="40" placeholder="Например: Старший куратор"></label><label>Приоритет (1–700)<input id="roleRankInput" type="number" min="1" max="700" value="150" required></label><label>Цвет роли<input id="roleColorInput" type="color" value="#d85b68"></label><label>Описание<input id="roleDescriptionInput" maxlength="180" placeholder="За что отвечает роль"></label></div>
    <div class="permission-heading">Разрешения роли</div><div class="permission-grid">${checks}</div><div class="role-form-actions"><button class="small-primary" type="submit" id="roleSaveButton">＋ Создать роль</button><button class="reaction-button" type="button" id="roleCancelEdit">Сбросить</button></div></form>
    <div class="role-list-heading">Созданные и системные роли</div><div id="adminRoleList" class="admin-role-list">${adminRolesMarkup(currentAdminRoles)}</div></section>`;
}
function adminRolesMarkup(roles){
  return roles.map(role=>`<div class="admin-role-row"><span class="role-color-dot" style="background:${escapeHtml(role.color)}"></span><div class="admin-role-main"><strong>${escapeHtml(role.label)}</strong><small>${escapeHtml(role.key)} · приоритет ${role.rank} · ${role.usersCount||0} пользователей</small><p>${escapeHtml(role.description||'')}</p></div><span class="role-pill" style="color:${escapeHtml(role.color)}">${role.isSystem?'СИСТЕМНАЯ':'СВОЯ'}</span>${!role.isSystem?`<button class="small-ban" data-edit-role="${role.id}">Изменить</button><button class="small-ban danger-button" data-delete-role="${role.id}">Удалить</button>`:''}</div>`).join('')||'<div class="empty-state">Ролей пока нет.</div>';
}
function wireRoleManager(){
  const form=$('roleForm');if(!form)return;
  const reset=()=>{$('roleEditId').value='';form.reset();$('roleRankInput').value='150';$('roleColorInput').value='#d85b68';$('roleSaveButton').textContent='＋ Создать роль';};
  $('roleCancelEdit').onclick=reset;
  form.onsubmit=async event=>{
    event.preventDefault();
    const payload={label:$('roleLabelInput').value.trim(),description:$('roleDescriptionInput').value.trim(),rank:Number($('roleRankInput').value),color:$('roleColorInput').value,permissions:[...form.querySelectorAll('.permission-option input:checked')].map(input=>input.value)};
    const editing=$('roleEditId').value;
    try{
      if(editing)await apiFetch(`/api/admin/roles/${editing}`,{method:'PUT',body:JSON.stringify(payload)});
      else await apiFetch('/api/admin/roles',{method:'POST',body:JSON.stringify(payload)});
      showToast(editing?'Роль обновлена':'Новая роль создана');await renderAdmin();
    }catch(error){showToast(error.message);}
  };
  $('adminRoleList').querySelectorAll('[data-edit-role]').forEach(button=>button.onclick=()=>{
    const role=currentAdminRoles.find(item=>item.id===Number(button.dataset.editRole));if(!role)return;
    $('roleEditId').value=role.id;$('roleLabelInput').value=role.label;$('roleDescriptionInput').value=role.description||'';$('roleRankInput').value=role.rank;$('roleColorInput').value=role.color;
    form.querySelectorAll('.permission-option input').forEach(input=>input.checked=(role.permissions||[]).includes(input.value));$('roleSaveButton').textContent='Сохранить изменения';form.scrollIntoView({behavior:'smooth',block:'center'});
  });
  $('adminRoleList').querySelectorAll('[data-delete-role]').forEach(button=>button.onclick=async()=>{
    const role=currentAdminRoles.find(item=>item.id===Number(button.dataset.deleteRole));if(!role||!confirm(`Удалить роль «${role.label}»?`))return;
    try{await apiFetch(`/api/admin/roles/${role.id}`,{method:'DELETE'});showToast('Роль удалена');await renderAdmin();}catch(error){showToast(error.message);}
  });
}
function wireAdminActions(){
  document.querySelectorAll('[data-assign-role]').forEach(button=>button.onclick=async()=>{
    const id=button.dataset.assignRole,role=$(`role-select-${id}`)||document.querySelector(`[data-role-select="${id}"]`);
    try{await apiFetch(`/api/admin/users/${id}/role`,{method:'POST',body:JSON.stringify({role:role.value})});showToast('Роль пользователя обновлена');await renderAdmin();}catch(error){showToast(error.message);}
  });
  document.querySelectorAll('[data-ban-user]').forEach(button=>button.onclick=async()=>{
    const id=button.dataset.banUser;if(!confirm('Заблокировать пользователя на 1 час?'))return;
    try{await apiFetch(`/api/admin/users/${id}/ban`,{method:'POST',body:JSON.stringify({minutes:60,reason:'Решение администрации Love Russia'})});showToast('Пользователь заблокирован');await renderAdmin();}catch(error){showToast(error.message);}
  });
  document.querySelectorAll('[data-unban-user]').forEach(button=>button.onclick=async()=>{
    try{await apiFetch(`/api/admin/users/${button.dataset.unbanUser}/ban`,{method:'DELETE'});showToast('Блокировка снята');await renderAdmin();}catch(error){showToast(error.message);}
  });
}
function wireBroadcast(){
  const form=$('broadcastForm');if(!form)return;
  form.onsubmit=async event=>{
    event.preventDefault();
    try{
      const result=await apiFetch('/api/admin/notifications/broadcast',{method:'POST',body:JSON.stringify({title:$('broadcastTitle').value.trim(),body:$('broadcastBody').value.trim()})});
      form.reset();showToast(`Уведомление создано для ${result.recipients} аккаунтов`);
    }catch(error){showToast(error.message);}
  };
}

async function wireAudit(){
  if(!$('auditList'))return;
  try{const data=await apiFetch('/api/admin/audit');$('auditList').innerHTML=data.logs.length?data.logs.map(log=>`<div class="audit-row"><strong>${escapeHtml(log.action)}</strong><span>${escapeHtml(log.actor_name||'Система')} · ${formatDate(log.created_at)}</span></div>`).join(''):'Журнал пока пуст.';}catch(error){$('auditList').textContent=error.message;}
}

async function bootLoveRussia(){
  // Remove old v1 demo content stored only in this browser; all current forum content is server-backed.
  for (const key of ['love_topics','love_replies','love_liked']) localStorage.removeItem(key);
  await syncCurrentUser();await refreshAuthAvailability();if(user)await refreshNotifications();
  const params=new URLSearchParams(location.search);
  if(params.has('auth')){history.replaceState({},'','/');showToast('Добро пожаловать в Love Russia!');}
  if(params.has('auth_error')){const reason=params.get('reason');history.replaceState({},'','/');showToast(reason||'Не удалось выполнить вход. Проверь настройки OAuth и адрес возврата.');}
  try{await loadCategories();}catch(error){console.error('[categories]',error);}
  await renderHome();await refreshStats();await refreshSidebarServers();
  if(location.hash.startsWith('#topic-')){const topicId=Number(location.hash.slice(7));if(topicId)await renderTopic(topicId);}
}
void bootLoveRussia();
setInterval(()=>{void refreshStats();void refreshSidebarServers();if(user){void presenceHeartbeat();void refreshNotifications();}},30_000);
