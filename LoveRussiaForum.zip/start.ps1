$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$projectEnv = Join-Path $projectRoot '.env'

if (-not (Test-Path (Join-Path $projectRoot 'package.json'))) {
    throw "Не найден package.json в папке проекта: $projectRoot"
}

$parentRoot = Split-Path -Parent $projectRoot
$legacyEnv = Join-Path $parentRoot '.env'
if (-not (Test-Path $projectEnv) -and (Test-Path $legacyEnv)) {
    Move-Item -LiteralPath $legacyEnv -Destination $projectEnv
    Write-Host 'Перенёс найденный .env в папку проекта.' -ForegroundColor Yellow
}

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    throw 'Node.js 20+ не найден. Установи Node.js и открой PowerShell заново.'
}

Push-Location $projectRoot
try {
    if (-not (Test-Path '.env')) { & (Join-Path $projectRoot 'setup.ps1') }
    if (-not (Test-Path '.env')) { throw '.env не создан.' }

    # Preserve every existing secret and append only missing email settings.
    $existing = Get-Content '.env' -ErrorAction Stop
    $defaults = [ordered]@{
        'ADMIN_EMAIL' = 'vikamisustina76@gmail.com'
        'EMAIL_CODE_TTL_MINUTES' = '10'
        'SMTP_HOST' = 'smtp.gmail.com'
        'SMTP_PORT' = '465'
        'SMTP_SECURE' = 'true'
        'SMTP_USER' = 'vikamisustina76@gmail.com'
        'SMTP_PASS' = ''
        'SMTP_FROM' = 'Love Russia <vikamisustina76@gmail.com>'
    }
    $missing = @()
    foreach ($key in $defaults.Keys) {
        if (-not ($existing | Where-Object { $_ -match "^\s*$([regex]::Escape($key))\s*=" })) {
            $missing += "$key=$($defaults[$key])"
        }
    }
    if ($missing.Count -gt 0) {
        Add-Content -LiteralPath '.env' -Value $missing -Encoding UTF8
        Write-Host 'Добавил недостающие настройки email в .env, прежние секреты сохранены.' -ForegroundColor Green
    }

    if (-not (Test-Path 'node_modules')) {
        Write-Host 'Устанавливаю зависимости...' -ForegroundColor Cyan
        npm install
        if ($LASTEXITCODE -ne 0) { throw "npm install завершился с кодом $LASTEXITCODE." }
    }

    $smtpPassLine = Get-Content '.env' | Where-Object { $_ -match '^\s*SMTP_PASS\s*=' } | Select-Object -First 1
    if (-not $smtpPassLine -or ($smtpPassLine -split '=',2)[1].Trim().Length -eq 0) {
        Write-Host 'SMTP_PASS пока пустой. Форум запустится, но отправка кодов email не заработает до настройки Gmail App Password.' -ForegroundColor Yellow
    }
    Write-Host 'Запускаю Love Russia...' -ForegroundColor Red
    Write-Host "Папка проекта: $projectRoot"
    npm start
    if ($LASTEXITCODE -ne 0) { throw "Сервер завершился с кодом $LASTEXITCODE." }
}
finally { Pop-Location }
