$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$envPath = Join-Path $projectRoot '.env'

if (Test-Path $envPath) {
    Write-Host '.env уже существует — не перезаписываю секреты.' -ForegroundColor Yellow
    return
}

$bytes = New-Object byte[] 48
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
$sessionSecret = [Convert]::ToBase64String($bytes)

$lines = @(
    'NODE_ENV=development',
    'PORT=3000',
    'PUBLIC_URL=http://localhost:3000',
    "SESSION_SECRET=$sessionSecret",
    'ADMIN_EMAIL=vikamisustina76@gmail.com',
    'EMAIL_CODE_TTL_MINUTES=10',
    'SMTP_HOST=smtp.gmail.com',
    'SMTP_PORT=465',
    'SMTP_SECURE=true',
    'SMTP_USER=vikamisustina76@gmail.com',
    'SMTP_PASS=',
    'SMTP_FROM=Love Russia <vikamisustina76@gmail.com>',
    'GAME_STATUS_API_URL='
)
[System.IO.File]::WriteAllLines($envPath, $lines, (New-Object System.Text.UTF8Encoding($false)))

Write-Host ".env создан: $envPath" -ForegroundColor Green
Write-Host 'SESSION_SECRET сгенерирован автоматически.' -ForegroundColor Green
Write-Host 'Файл .env исключён из Git. Не отправляй его другим людям и не загружай в репозиторий.' -ForegroundColor Yellow
Write-Host 'Для отправки кодов добавь SMTP_PASS — пароль приложения Gmail, НЕ обычный пароль от Google.' -ForegroundColor Yellow
Write-Host 'Затем перезапусти npm start.' -ForegroundColor Cyan
