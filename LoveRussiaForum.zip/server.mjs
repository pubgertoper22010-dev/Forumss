import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import Database from 'better-sqlite3';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import nodemailer from 'nodemailer';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdirSync } from 'node:fs';
import { randomInt, createHash, timingSafeEqual } from 'node:crypto';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const PUBLIC_URL = (process.env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const NODE_ENV = process.env.NODE_ENV || 'development';
const IS_PROD = NODE_ENV === 'production';
const SESSION_SECRET = process.env.SESSION_SECRET || '';
const ADMIN_EMAIL = String(process.env.ADMIN_EMAIL || 'vikamisustina76@gmail.com').trim().toLowerCase();
const SMTP_HOST = String(process.env.SMTP_HOST || '').trim();
const SMTP_PORT = Number(process.env.SMTP_PORT || 465);
const SMTP_SECURE = String(process.env.SMTP_SECURE || (SMTP_PORT === 465 ? 'true' : 'false')).toLowerCase() === 'true';
const SMTP_USER = String(process.env.SMTP_USER || '').trim();
const SMTP_PASS = String(process.env.SMTP_PASS || '').replace(/\s+/g, '');
const SMTP_FROM = String(process.env.SMTP_FROM || SMTP_USER).trim();
const EMAIL_CODE_TTL_MINUTES = Math.max(5, Math.min(20, Number(process.env.EMAIL_CODE_TTL_MINUTES || 10)));
const mailer = SMTP_HOST && SMTP_USER && SMTP_PASS && SMTP_FROM
  ? nodemailer.createTransport({ host: SMTP_HOST, port: SMTP_PORT, secure: SMTP_SECURE, auth: { user: SMTP_USER, pass: SMTP_PASS }, connectionTimeout: 12000, greetingTimeout: 12000, socketTimeout: 20000 })
  : null;
const GAME_STATUS_API_URL = process.env.GAME_STATUS_API_URL || '';

if (!SESSION_SECRET || SESSION_SECRET.length < 32 || SESSION_SECRET.includes('CHANGE_ME')) {
  console.error('ОШИБКА: задай SESSION_SECRET длиной не менее 32 символов в .env');
  process.exit(1);
}
if (IS_PROD && !PUBLIC_URL.startsWith('https://')) {
  console.error('ОШИБКА: в production PUBLIC_URL должен начинаться с https://');
  process.exit(1);
}
if (GAME_STATUS_API_URL) {
  const statusUrl = new URL(GAME_STATUS_API_URL);
  if (statusUrl.protocol !== 'https:') throw new Error('GAME_STATUS_API_URL должен использовать HTTPS.');
}

const app = express();
app.disable('x-powered-by');
if (IS_PROD) app.set('trust proxy', 1);

const dataDir = path.join(__dirname, 'data');
mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'love-russia.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    display_name TEXT NOT NULL,
    bio TEXT NOT NULL DEFAULT '',
    signature TEXT NOT NULL DEFAULT '',
    avatar_url TEXT NOT NULL DEFAULT '',
    accent TEXT NOT NULL DEFAULT 'red',
    role TEXT NOT NULL DEFAULT 'player',
    created_at TEXT NOT NULL,
    last_login_at TEXT NOT NULL,
    last_seen_at TEXT,
    banned_until INTEGER,
    ban_reason TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS identities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    provider TEXT NOT NULL,
    provider_id TEXT NOT NULL,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    UNIQUE(provider, provider_id)
  );
  CREATE TABLE IF NOT EXISTS email_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    code_hash TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    request_ip TEXT NOT NULL DEFAULT ''
  );
  CREATE INDEX IF NOT EXISTS email_codes_lookup_idx ON email_codes(email, id DESC);
  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL DEFAULT 'info',
    title TEXT NOT NULL,
    body TEXT NOT NULL DEFAULT '',
    link TEXT NOT NULL DEFAULT '',
    read_at TEXT,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS notifications_user_idx ON notifications(user_id, id DESC);
  CREATE INDEX IF NOT EXISTS identities_user_idx ON identities(user_id);
  CREATE TABLE IF NOT EXISTS sessions (
    sid TEXT PRIMARY KEY,
    sess TEXT NOT NULL,
    expires INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires);
  CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role_key TEXT NOT NULL UNIQUE,
    label TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    color TEXT NOT NULL DEFAULT '#9aa4ad',
    permissions_json TEXT NOT NULL DEFAULT '[]',
    rank INTEGER NOT NULL DEFAULT 0,
    is_system INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    group_title TEXT NOT NULL,
    group_icon TEXT NOT NULL DEFAULT '✳',
    group_note TEXT NOT NULL DEFAULT '',
    name TEXT NOT NULL,
    icon TEXT NOT NULL DEFAULT '▤',
    description TEXT NOT NULL DEFAULT '',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id TEXT NOT NULL REFERENCES categories(id),
    author_id INTEGER NOT NULL REFERENCES users(id),
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    pinned INTEGER NOT NULL DEFAULT 0,
    locked INTEGER NOT NULL DEFAULT 0,
    views INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS topics_category_idx ON topics(category_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS topics_author_idx ON topics(author_id);
  CREATE TABLE IF NOT EXISTS replies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
    author_id INTEGER NOT NULL REFERENCES users(id),
    body TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS replies_topic_idx ON replies(topic_id, created_at);
  CREATE TABLE IF NOT EXISTS topic_likes (
    topic_id INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    PRIMARY KEY(topic_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor_id INTEGER,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    details_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
  );
`);

function ensureColumn(table, column, definition) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all().map(row => row.name);
  if (!columns.includes(column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
}
ensureColumn('users', 'last_seen_at', 'TEXT');
ensureColumn('users', 'email', 'TEXT');
ensureColumn('users', 'email_verified_at', 'TEXT');
ensureColumn('users', 'email_notifications', 'INTEGER NOT NULL DEFAULT 1');
db.exec("CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique ON users(email) WHERE email IS NOT NULL AND email <> '';");

const permissionOptions = [
  ['admin.view', 'Открывать панель управления'],
  ['users.view', 'Просматривать пользователей'],
  ['users.ban', 'Выдавать и снимать блокировки'],
  ['users.assign_role', 'Назначать роли ниже собственной'],
  ['forum.moderate', 'Модерировать темы'],
  ['forum.pin', 'Закреплять темы'],
  ['forum.lock', 'Закрывать темы'],
  ['forum.delete', 'Удалять темы']
];
const allPermissions = new Set(permissionOptions.map(([key]) => key));
const nowIso = () => new Date().toISOString();
const roleSeeds = [
  ['owner','Владелец проекта','Полный доступ ко всем функциям.','#ff2638', [...allPermissions],1000],
  ['deputy_owner','Заместитель владельца','Помощь владельцу в управлении проектом.','#ff5361',['admin.view','users.view','users.ban','users.assign_role','forum.moderate','forum.pin','forum.lock','forum.delete','categories.manage','servers.manage','analytics.view'],900],
  ['project_manager','Руководитель проекта','Координация работы проекта.','#ff596b',['admin.view','users.view','users.ban','users.assign_role','forum.moderate','forum.pin','forum.lock','categories.manage','servers.manage','analytics.view'],850],
  ['technical_admin','Технический администратор','Техническое обслуживание форума и проекта.','#bb8cff',['admin.view','users.view','settings.manage','servers.manage','analytics.view'],830],
  ['head_admin','Главный администратор','Руководство администрацией.','#ff6573',['admin.view','users.view','users.ban','users.assign_role','forum.moderate','forum.pin','forum.lock','forum.delete','analytics.view'],800],
  ['senior_admin','Старший администратор','Расширенная модерация проекта.','#ff7480',['admin.view','users.view','users.ban','forum.moderate','forum.pin','forum.lock','forum.delete'],760],
  ['admin','Администратор','Администрирование сообщества.','#ff8290',['admin.view','users.view','users.ban','forum.moderate','forum.pin','forum.lock'],720],
  ['junior_admin','Младший администратор','Помощь администрации.','#e89ba2',['admin.view','users.view','forum.moderate'],680],
  ['head_moderator','Главный модератор','Руководство командой модерации.','#ed9d67',['admin.view','users.view','users.ban','forum.moderate','forum.pin','forum.lock'],650],
  ['senior_moderator','Старший модератор','Расширенная модерация форума.','#e9a36f',['admin.view','users.view','users.ban','forum.moderate','forum.pin','forum.lock'],620],
  ['moderator','Модератор','Следит за порядком на форуме.','#dfa978',['admin.view','users.view','forum.moderate','forum.lock'],580],
  ['junior_moderator','Младший модератор','Помощь в проверке публикаций.','#d5b18d',['admin.view','forum.moderate'],540],
  ['curator','Куратор','Курирует отдельные направления сообщества.','#c1a0ff',['admin.view','users.view','forum.moderate'],500],
  ['forum_manager','Менеджер форума','Организация разделов и контента.','#85b7ff',['admin.view','forum.moderate','forum.pin','categories.manage'],480],
  ['content_manager','Контент-менеджер','Работа с новостями и публикациями.','#80c5e8',['admin.view','forum.moderate','forum.pin'],460],
  ['community_manager','Менеджер сообщества','Развитие сообщества и коммуникация.','#7dcbb9',['admin.view','users.view'],440],
  ['support_lead','Руководитель поддержки','Координация службы поддержки.','#a6c5a0',['admin.view','users.view'],420],
  ['support','Техническая поддержка','Помощь пользователям.','#9bb8a4',['users.view'],380],
  ['event_manager','Организатор мероприятий','Планирование форумных и игровых событий.','#e5b46f',[],360],
  ['media_manager','Медиа-менеджер','Работа с медиа и публикациями проекта.','#c6a2e8',[],340],
  ['developer','Разработчик','Разработка и поддержка систем проекта.','#83b9df',[],320],
  ['faction_manager','Куратор фракций','Координация игровых организаций.','#a7c77e',[],300],
  ['faction_leader','Лидер фракции','Руководитель игровой организации.','#e3c36c',[],280],
  ['deputy_faction_leader','Заместитель лидера фракции','Заместитель руководителя организации.','#d8c987',[],260],
  ['faction_curator','Заместитель/куратор фракции','Помощь руководству фракции.','#c6cb8b',[],240],
  ['faction_member','Участник фракции','Участник игровой организации.','#a9b9a8',[],200],
  ['verified','Подтверждённый участник','Подтверждённый аккаунт сообщества.','#77c9b5',[],100],
  ['player','Игрок','Стандартная роль зарегистрированного игрока.','#9aa4ad',[],0],
  ['muted','Ограничен в общении','Временное ограничение общения.','#d49a75',[],-10],
  ['banned','Заблокирован','Заблокированный пользователь.','#e36d72',[],-20]
];
const insertRole = db.prepare(`INSERT OR IGNORE INTO roles(role_key,label,description,color,permissions_json,rank,is_system,created_at)
  VALUES(?,?,?,?,?,?,1,?)`);
for (const [key,label,description,color,permissions,rank] of roleSeeds) {
  insertRole.run(key,label,description,color,JSON.stringify(permissions.filter(permission => allPermissions.has(permission))),rank,nowIso());
}

const categorySeeds = [
  ['ИНФОРМАЦИЯ О ПРОЕКТЕ','✳','ВСЁ О LOVE RUSSIA',[
    ['news','Новости проекта','✦','Официальные объявления и новости проекта'],
    ['updates','Обновления','↗','Обновления, исправления и планы разработки'],
    ['rules','Правила проекта','▤','Правила игры, форума и сообщества'],
    ['questions','Вопросы и помощь','?','Вопросы по игре, форуму и аккаунтам']
  ]],
  ['ГОСУДАРСТВЕННЫЕ ОРГАНИЗАЦИИ','⌂','ГОСУДАРСТВЕННЫЕ ФРАКЦИИ',[
    ['government','Правительство','♙','Аппарат правительства и ведомства'],
    ['mvd','Министерство внутренних дел','✧','УМВД, подразделения, набор и отчётность'],
    ['fsb','Федеральная служба безопасности','⬡','УФСБ, руководство и служебные объявления'],
    ['mchs','МЧС','✚','Спасательная служба и набор'],
    ['army','Вооружённые силы','⌖','Воинские подразделения и набор'],
    ['fsin','ФСИН','▥','Служба исполнения наказаний'],
    ['hospital','Больница','✚','Медицинские организации и набор']
  ]],
  ['НЕФОРМАЛЬНЫЕ ОРГАНИЗАЦИИ','◈','КРИМИНАЛЬНЫЙ МИР RP',[
    ['opg','Организованные группировки','◉','ОПГ, составы, дипломатия и RP-истории']
  ]],
  ['ЖИЗНЬ СООБЩЕСТВА','◎','ИГРОКИ И ОБЩЕНИЕ',[
    ['applications','Заявления и заявки','⌁','Заявки во фракции и обращения'],
    ['complaints','Жалобы и обращения','⚑','Обращения к администрации проекта'],
    ['events','Мероприятия','✳','Конкурсы, встречи и игровые события'],
    ['offtopic','Свободное общение','☻','Знакомства, скриншоты и общение']
  ]]
];
const insertCategory = db.prepare(`INSERT OR IGNORE INTO categories(id,group_title,group_icon,group_note,name,icon,description,sort_order,created_at)
  VALUES(?,?,?,?,?,?,?,?,?)`);
let categoryOrder = 0;
for (const [groupTitle,groupIcon,groupNote,items] of categorySeeds) {
  for (const [id,name,icon,description] of items) insertCategory.run(id,groupTitle,groupIcon,groupNote,name,icon,description,categoryOrder++,nowIso());
}

const roleByKey = db.prepare('SELECT * FROM roles WHERE role_key = ?');
const getUserById = db.prepare('SELECT * FROM users WHERE id = ?');
const getIdentity = db.prepare('SELECT user_id FROM identities WHERE provider = ? AND provider_id = ?');
const getIdentityProviders = db.prepare('SELECT provider FROM identities WHERE user_id = ?');
function rolePermissions(roleKey) {
  const role = roleByKey.get(roleKey) || roleByKey.get('player');
  try { return JSON.parse(role.permissions_json); } catch { return []; }
}
function hasPermission(roleKey, permission) {
  if (roleKey === 'owner') return true;
  const permissions = rolePermissions(roleKey);
  return permissions.includes('*') || permissions.includes(permission);
}
function safeUser(row) {
  if (!row) return null;
  const role = roleByKey.get(row.role) || roleByKey.get('player');
  return {
    id: row.id,
    displayName: row.display_name,
    bio: row.bio,
    signature: row.signature,
    avatarUrl: row.avatar_url,
    accent: row.accent,
    role: role.role_key,
    roleLabel: role.label,
    roleColor: role.color,
    permissions: rolePermissions(role.role_key),
    providers: getIdentityProviders.all(row.id).map(x => x.provider),
    email: row.email || '',
    emailVerifiedAt: row.email_verified_at || null,
    emailNotifications: Boolean(row.email_notifications),
    createdAt: row.created_at,
    lastLoginAt: row.last_login_at,
    lastSeenAt: row.last_seen_at,
    bannedUntil: row.banned_until,
    banReason: row.ban_reason
  };
}
function audit(actorId, action, targetType, targetId, details = {}) {
  db.prepare('INSERT INTO audit_logs(actor_id,action,target_type,target_id,details_json,created_at) VALUES(?,?,?,?,?,?)')
    .run(actorId || null, action, targetType, String(targetId), JSON.stringify(details), nowIso());
}
function requireAuth(req,res,next) {
  if (!req.session.userId) return res.status(401).json({error:'Сначала войди в аккаунт.'});
  const row = getUserById.get(req.session.userId);
  if (!row) return req.session.destroy(() => res.status(401).json({error:'Сессия завершена. Войди снова.'}));
  if (row.banned_until && row.banned_until > Date.now()) return res.status(403).json({error:`Аккаунт ограничен до ${new Date(row.banned_until).toLocaleString('ru-RU')}.`});
  req.user = row;
  next();
}
function requirePermission(permission) {
  return (req,res,next) => requireAuth(req,res,() => {
    if (!hasPermission(req.user.role,permission)) return res.status(403).json({error:'Недостаточно прав для этого действия.'});
    next();
  });
}
function requireForumPosting(req,res,next) {
  requireAuth(req,res,() => {
    if (req.user.role === 'muted' || req.user.role === 'banned') {
      return res.status(403).json({error: req.user.role === 'muted' ? 'Тебе запрещено публиковать темы и ответы.' : 'Этот аккаунт заблокирован.'});
    }
    next();
  });
}
function requireOwner(req,res,next) {
  requireAuth(req,res,() => {
    if (req.user.role !== 'owner') return res.status(403).json({error:'Это действие доступно только владельцу проекта.'});
    next();
  });
}
class SQLiteSessionStore extends session.Store {
  get(sid,callback) {
    try { const row=db.prepare('SELECT sess,expires FROM sessions WHERE sid=?').get(sid); if(!row)return callback(null,null); if(row.expires<=Date.now()){db.prepare('DELETE FROM sessions WHERE sid=?').run(sid);return callback(null,null);} callback(null,JSON.parse(row.sess)); }
    catch(error){callback(error);}
  }
  set(sid,sess,callback=()=>{}) {
    try { const expires=sess.cookie?.expires?new Date(sess.cookie.expires).getTime():Date.now()+7*86400000; db.prepare('INSERT INTO sessions(sid,sess,expires) VALUES(?,?,?) ON CONFLICT(sid) DO UPDATE SET sess=excluded.sess,expires=excluded.expires').run(sid,JSON.stringify(sess),expires); callback(null); }
    catch(error){callback(error);}
  }
  destroy(sid,callback=()=>{}) { try{db.prepare('DELETE FROM sessions WHERE sid=?').run(sid);callback(null);}catch(error){callback(error);} }
  touch(sid,sess,callback=()=>{}) { this.set(sid,sess,callback); }
}

app.use(helmet({
  contentSecurityPolicy:{directives:{
    defaultSrc:["'self'"],baseUri:["'self'"],objectSrc:["'none'"],frameAncestors:["'none'"],
    imgSrc:["'self'",'data:','https:'],styleSrc:["'self'","'unsafe-inline'",'https://fonts.googleapis.com'],
    fontSrc:["'self'",'https://fonts.gstatic.com','data:'],scriptSrc:["'self'",'https://unpkg.com'],
    connectSrc:["'self'"],formAction:["'self'"]
  }},
  crossOriginOpenerPolicy:{policy:'same-origin-allow-popups'}
}));
app.use(express.json({limit:'40kb'}));
app.use(express.urlencoded({extended:false,limit:'20kb'}));
app.use(session({
  name:'love_russia.sid',secret:SESSION_SECRET,store:new SQLiteSessionStore(),resave:false,saveUninitialized:false,rolling:true,
  cookie:{httpOnly:true,secure:IS_PROD,sameSite:'lax',maxAge:7*24*60*60*1000}
}));
app.use((req,res,next)=>{
  if (['POST','PUT','PATCH','DELETE'].includes(req.method) && req.path.startsWith('/api/')) {
    const origin=req.get('origin');
    if (origin) {
      try { if (new URL(origin).host !== req.get('host')) return res.status(403).json({error:'Запрос с другого сайта отклонён.'}); }
      catch { return res.status(403).json({error:'Некорректный источник запроса.'}); }
    }
  }
  next();
});
app.use('/api',rateLimit({windowMs:60_000,limit:180,standardHeaders:'draft-8',legacyHeaders:false}));
app.use('/auth',rateLimit({windowMs:10*60_000,limit:30,standardHeaders:'draft-8',legacyHeaders:false}));

app.get('/api/health',(_req,res)=>res.json({ok:true,service:'Love Russia Forum',database:'connected',version:'5.0.0',auth:{email:Boolean(mailer)},notifications:true,publicUrl:PUBLIC_URL}));
app.get('/api/config',(_req,res)=>res.json({
  publicUrl:PUBLIC_URL,
  auth:{email:Boolean(mailer)},
  authHints:{email:mailer?'Регистрация по email доступна.':'SMTP не настроен: добавь SMTP_HOST, SMTP_USER и SMTP_PASS в .env.'},
  notifications:true
}));

const emailRequestLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 5, standardHeaders: 'draft-8', legacyHeaders: false });
const normalizeEmail = value => String(value || '').trim().toLowerCase();
const isValidEmail = value => value.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
const hashEmailCode = (email, code) => createHash('sha256').update(`${SESSION_SECRET}:${email}:${code}`).digest('hex');
const escapeEmailHtml = value => String(value || '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
async function sendEmail(to, subject, text, html = '') {
  if (!mailer) throw new Error('SMTP не настроен');
  return mailer.sendMail({ from: SMTP_FROM, to, subject, text, ...(html ? { html } : {}) });
}
function createNotification(userId, type, title, body = '', link = '', options = {}) {
  const targetId = Number(userId);
  if (!targetId || !getUserById.get(targetId)) return null;
  const result = db.prepare('INSERT INTO notifications(user_id,type,title,body,link,created_at) VALUES(?,?,?,?,?,?)')
    .run(targetId, String(type || 'info').slice(0,24), String(title || 'Уведомление').slice(0,100), String(body || '').slice(0,500), String(link || '').slice(0,300), nowIso());
  if (options.sendEmail !== false) {
    const target = db.prepare('SELECT email,email_verified_at,email_notifications FROM users WHERE id=?').get(targetId);
    if (mailer && target?.email && target.email_verified_at && target.email_notifications) {
      const safeTitle = String(title || 'Уведомление');
      const safeBody = String(body || '');
      const url = link ? `${PUBLIC_URL}${link.startsWith('/') ? link : `/${link}`}` : PUBLIC_URL;
      void sendEmail(target.email, `Love Russia — ${safeTitle}`, `${safeTitle}\n\n${safeBody}\n\nОткрыть форум: ${url}`, `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#202020"><h2>${escapeEmailHtml(safeTitle)}</h2><p>${escapeEmailHtml(safeBody).replace(/\n/g,'<br>')}</p><p><a href="${escapeEmailHtml(url)}">Открыть Love Russia</a></p></div>`)
        .catch(error => console.error('[notification email]', error.message));
    }
  }
  return Number(result.lastInsertRowid);
}

app.post('/api/auth/email/request', emailRequestLimiter, async (req, res) => {
  const email = normalizeEmail(req.body.email);
  if (!isValidEmail(email)) return res.status(400).json({ error: 'Введи корректный email-адрес.' });
  if (!mailer) return res.status(503).json({ error: 'Отправка писем не настроена. Администратору нужно добавить SMTP_HOST, SMTP_USER и SMTP_PASS в .env.' });
  const last = db.prepare('SELECT created_at FROM email_codes WHERE email=? ORDER BY id DESC LIMIT 1').get(email);
  if (last && Date.now() - Date.parse(last.created_at) < 60_000) return res.status(429).json({ error: 'Подожди минуту перед повторной отправкой кода.' });
  const hourAgo = new Date(Date.now() - 60 * 60_000).toISOString();
  const sentLastHour = db.prepare('SELECT COUNT(*) AS count FROM email_codes WHERE email=? AND created_at>=?').get(email, hourAgo).count;
  if (sentLastHour >= 5) return res.status(429).json({ error: 'Для этого адреса достигнут лимит писем. Попробуй позже.' });
  const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
  const expiresAt = Date.now() + EMAIL_CODE_TTL_MINUTES * 60_000;
  db.prepare('DELETE FROM email_codes WHERE email=? AND created_at<?').run(email, new Date(Date.now() - 60 * 60_000).toISOString());
  const saved = db.prepare('INSERT INTO email_codes(email,code_hash,expires_at,created_at,request_ip) VALUES(?,?,?,?,?)')
    .run(email, hashEmailCode(email, code), expiresAt, nowIso(), String(req.ip || '').slice(0,80));
  try {
    await sendEmail(email, 'Код входа в Love Russia', `Твой код подтверждения: ${code}\n\nОн действует ${EMAIL_CODE_TTL_MINUTES} минут. Если ты не запрашивал вход, просто проигнорируй это письмо.`, `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#202020"><h2>Вход в Love Russia</h2><p>Твой код подтверждения:</p><div style="font-size:32px;font-weight:bold;letter-spacing:8px;padding:16px;background:#f4f4f4;border-radius:10px;text-align:center">${code}</div><p>Код действует ${EMAIL_CODE_TTL_MINUTES} минут. Если ты не запрашивал вход, проигнорируй это письмо.</p></div>`);
    res.json({ ok: true, message: `Код отправлен на ${email}. Проверь также папку «Спам».` });
  } catch (error) {
    db.prepare('DELETE FROM email_codes WHERE id=?').run(saved.lastInsertRowid);
    console.error('[email code send]', error.message);
    res.status(502).json({ error: 'Не удалось отправить письмо. Проверь SMTP-настройки и попробуй ещё раз.' });
  }
});

app.post('/api/auth/email/verify', (req, res) => {
  const email = normalizeEmail(req.body.email);
  const code = String(req.body.code || '').trim();
  const displayNameInput = String(req.body.displayName || '').trim().replace(/\s+/g, ' ');
  if (!isValidEmail(email) || !/^\d{6}$/.test(code)) return res.status(400).json({ error: 'Проверь email и введи шестизначный код из письма.' });
  const pending = db.prepare('SELECT * FROM email_codes WHERE email=? ORDER BY id DESC LIMIT 1').get(email);
  if (!pending || pending.expires_at < Date.now()) {
    if (pending) db.prepare('DELETE FROM email_codes WHERE email=?').run(email);
    return res.status(400).json({ error: 'Код истёк или не найден. Запроси новый код.' });
  }
  if (pending.attempts >= 5) {
    db.prepare('DELETE FROM email_codes WHERE email=?').run(email);
    return res.status(429).json({ error: 'Слишком много неверных попыток. Запроси новый код.' });
  }
  const expected = pending.code_hash;
  const actual = hashEmailCode(email, code);
  const expectedBuffer = Buffer.from(expected, 'hex');
  const actualBuffer = Buffer.from(actual, 'hex');
  if (expectedBuffer.length !== actualBuffer.length || !timingSafeEqual(expectedBuffer, actualBuffer)) {
    db.prepare('UPDATE email_codes SET attempts=attempts+1 WHERE id=?').run(pending.id);
    return res.status(400).json({ error: 'Неверный код. Проверь письмо и попробуй ещё раз.' });
  }
  db.prepare('DELETE FROM email_codes WHERE email=?').run(email);
  const now = nowIso();
  let userId;
  let isNewUser = false;
  const transaction = db.transaction(() => {
    let account = db.prepare('SELECT * FROM users WHERE lower(email)=?').get(email);
    if (!account) {
      const emailName = email.split('@')[0].replace(/[._-]+/g, ' ').trim();
      const displayName = (displayNameInput || emailName || 'Игрок').slice(0,32);
      const initialRole = email === ADMIN_EMAIL ? 'owner' : 'player';
      const result = db.prepare('INSERT INTO users(display_name,email,email_verified_at,email_notifications,role,created_at,last_login_at,last_seen_at) VALUES(?,?,?,?,?,?,?,?)')
        .run(displayName,email,now,1,initialRole,now,now,now);
      userId = Number(result.lastInsertRowid);
      isNewUser = true;
    } else {
      userId = account.id;
      db.prepare('UPDATE users SET email_verified_at=COALESCE(email_verified_at,?),last_login_at=?,last_seen_at=? WHERE id=?').run(now,now,now,userId);
    }
    if (email === ADMIN_EMAIL) db.prepare("UPDATE users SET role='owner' WHERE id=?").run(userId);
    db.prepare("INSERT OR IGNORE INTO identities(provider,provider_id,user_id,created_at) VALUES('email',?,?,?)").run(email,userId,now);
    if (isNewUser) createNotification(userId,'welcome','Добро пожаловать в Love Russia','Твой email подтверждён. Настрой профиль и присоединяйся к обсуждениям.','/',{sendEmail:false});
    if (email === ADMIN_EMAIL) audit(userId,'owner.email.bootstrap','user',userId,{email});
  });
  try { transaction(); }
  catch (error) { console.error('[email verify]', error.message); return res.status(500).json({ error: 'Не удалось создать аккаунт. Попробуй ещё раз.' }); }
  const account = getUserById.get(userId);
  if (account.banned_until && account.banned_until > Date.now()) return res.status(403).json({ error: 'Этот аккаунт временно ограничен.' });
  req.session.regenerate(error => {
    if (error) return res.status(500).json({ error: 'Не удалось создать сессию. Попробуй войти ещё раз.' });
    req.session.userId = userId;
    req.session.save(saveError => {
      if (saveError) return res.status(500).json({ error: 'Не удалось сохранить сессию.' });
      res.json({ ok: true, user: safeUser(getUserById.get(userId)), newAccount: isNewUser });
    });
  });
});

app.get('/api/notifications', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT id,type,title,body,link,read_at,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.user.id);
  const unread = db.prepare('SELECT COUNT(*) AS count FROM notifications WHERE user_id=? AND read_at IS NULL').get(req.user.id).count;
  res.json({ notifications: rows, unread });
});
app.post('/api/notifications/:id/read', requireAuth, (req, res) => {
  const id = Number(req.params.id);
  db.prepare('UPDATE notifications SET read_at=? WHERE id=? AND user_id=? AND read_at IS NULL').run(nowIso(), id, req.user.id);
  res.json({ ok: true });
});
app.post('/api/notifications/read-all', requireAuth, (req, res) => {
  db.prepare('UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL').run(nowIso(), req.user.id);
  res.json({ ok: true });
});
app.put('/api/notifications/settings', requireAuth, (req, res) => {
  const enabled = req.body.emailNotifications === false ? 0 : 1;
  db.prepare('UPDATE users SET email_notifications=? WHERE id=?').run(enabled, req.user.id);
  res.json({ ok: true, emailNotifications: Boolean(enabled) });
});

app.get('/api/me',(req,res)=>res.json({user:req.session.userId?safeUser(getUserById.get(req.session.userId)):null}));
app.post('/api/logout',requireAuth,(req,res)=>req.session.destroy(error=>{if(error)return res.status(500).json({error:'Не удалось завершить сессию.'});res.clearCookie('love_russia.sid');res.json({ok:true});}));
app.post('/api/presence',requireAuth,(req,res)=>{const now=nowIso();db.prepare('UPDATE users SET last_seen_at=? WHERE id=?').run(now,req.user.id);res.json({ok:true});});

app.get('/api/stats',(_req,res)=>{
  const now=Date.now(); const onlineSince=new Date(now-90_000).toISOString();
  const members=db.prepare('SELECT COUNT(*) AS count FROM users').get().count;
  const online=db.prepare('SELECT COUNT(*) AS count FROM users WHERE last_seen_at >= ? AND (banned_until IS NULL OR banned_until <= ?)').get(onlineSince,now).count;
  const topicCount=db.prepare('SELECT COUNT(*) AS count FROM topics').get().count;
  const replyCount=db.prepare('SELECT COUNT(*) AS count FROM replies').get().count;
  const latest=db.prepare('SELECT display_name FROM users ORDER BY id DESC LIMIT 1').get();
  const onlineUsers=db.prepare(`SELECT id,display_name,avatar_url FROM users
    WHERE last_seen_at>=? AND (banned_until IS NULL OR banned_until<=?)
    ORDER BY last_seen_at DESC LIMIT 5`).all(onlineSince,now);
  res.json({members,online,topics:topicCount,posts:topicCount+replyCount,lastRegistered:latest?.display_name||null,
    onlineUsers:onlineUsers.map(row=>({id:row.id,displayName:row.display_name,avatarUrl:row.avatar_url})),generatedAt:nowIso()});
});
app.get('/api/categories',(_req,res)=>{
  const categories=db.prepare(`SELECT c.*,
    (SELECT COUNT(*) FROM topics t WHERE t.category_id=c.id) AS topic_count,
    (SELECT COUNT(*) FROM replies r JOIN topics t2 ON t2.id=r.topic_id WHERE t2.category_id=c.id) AS reply_count
    FROM categories c ORDER BY c.sort_order,c.name`).all();
  const groups=[];
  for(const row of categories){let group=groups.find(g=>g.title===row.group_title);if(!group){group={title:row.group_title,icon:row.group_icon,note:row.group_note,items:[]};groups.push(group);}group.items.push({id:row.id,name:row.name,icon:row.icon,description:row.description,topics:row.topic_count,posts:row.topic_count+row.reply_count});}
  res.json({groups});
});
app.get('/api/topics',(req,res)=>{
  const category=String(req.query.category||'').trim();const query=String(req.query.q||'').trim().slice(0,80);
  let sql=`SELECT t.*,u.display_name AS author,u.avatar_url AS author_avatar,r.label AS author_role,
    (SELECT COUNT(*) FROM replies rp WHERE rp.topic_id=t.id) AS reply_count,
    (SELECT COUNT(*) FROM topic_likes lk WHERE lk.topic_id=t.id) AS like_count
    FROM topics t JOIN users u ON u.id=t.author_id LEFT JOIN roles r ON r.role_key=u.role WHERE 1=1`;
  const args=[];
  if(category){sql+=' AND t.category_id=?';args.push(category);}
  if(query){sql+=' AND (t.title LIKE ? OR t.body LIKE ? OR u.display_name LIKE ?)';args.push(`%${query}%`,`%${query}%`,`%${query}%`);}
  sql+=' ORDER BY t.pinned DESC,t.created_at DESC LIMIT 150';
  const rows=db.prepare(sql).all(...args);
  const categories=new Map(db.prepare('SELECT id,name FROM categories').all().map(c=>[c.id,c.name]));
  res.json({topics:rows.map(row=>({id:row.id,cat:row.category_id,categoryName:categories.get(row.category_id)||'Раздел',title:row.title,body:row.body,author:row.author,authorAvatar:row.author_avatar,authorRole:row.author_role||'Игрок',created:row.created_at,replies:row.reply_count,views:row.views,likes:row.like_count,pinned:Boolean(row.pinned),locked:Boolean(row.locked)}))});
});
app.get('/api/latest-topics',(_req,res)=>{
  const rows=db.prepare(`SELECT t.id,t.title,t.category_id,t.created_at,u.display_name AS author,
    (SELECT COUNT(*) FROM replies r WHERE r.topic_id=t.id) AS reply_count
    FROM topics t JOIN users u ON u.id=t.author_id ORDER BY t.created_at DESC LIMIT 4`).all();
  res.json({topics:rows.map(row=>({id:row.id,title:row.title,cat:row.category_id,author:row.author,created:row.created_at,replies:row.reply_count}))});
});
app.get('/api/topics/:id',(req,res)=>{
  const id=Number(req.params.id);if(!Number.isSafeInteger(id)||id<1)return res.status(400).json({error:'Некорректный номер темы.'});
  const topic=db.prepare(`SELECT t.*,u.display_name AS author,u.avatar_url AS author_avatar,r.label AS author_role,
    (SELECT COUNT(*) FROM replies rp WHERE rp.topic_id=t.id) AS reply_count,
    (SELECT COUNT(*) FROM topic_likes lk WHERE lk.topic_id=t.id) AS like_count
    FROM topics t JOIN users u ON u.id=t.author_id LEFT JOIN roles r ON r.role_key=u.role WHERE t.id=?`).get(id);
  if(!topic)return res.status(404).json({error:'Тема не найдена.'});
  db.prepare('UPDATE topics SET views=views+1 WHERE id=?').run(id);
  const replyRows=db.prepare(`SELECT p.id,p.body,p.created_at,u.id AS author_id,u.display_name AS author,u.avatar_url,r.label AS role_label
    FROM replies p JOIN users u ON u.id=p.author_id LEFT JOIN roles r ON r.role_key=u.role WHERE p.topic_id=? ORDER BY p.created_at ASC`).all(id);
  const liked=Boolean(req.session.userId && db.prepare('SELECT 1 FROM topic_likes WHERE topic_id=? AND user_id=?').get(id,req.session.userId));
  res.json({topic:{id:topic.id,cat:topic.category_id,title:topic.title,body:topic.body,author:topic.author,authorId:topic.author_id,authorAvatar:topic.author_avatar,authorRole:topic.author_role||'Игрок',created:topic.created_at,replies:topic.reply_count,views:topic.views+1,likes:topic.like_count,pinned:Boolean(topic.pinned),locked:Boolean(topic.locked),liked},replies:replyRows.map(r=>({id:r.id,authorId:r.author_id,author:r.author,role:r.role_label||'Игрок',body:r.body,created:r.created_at}))});
});
app.post('/api/topics',requireForumPosting,(req,res)=>{
  const category=String(req.body.category||'');const title=String(req.body.title||'').trim();const body=String(req.body.body||'').trim();
  if(!db.prepare('SELECT id FROM categories WHERE id=?').get(category))return res.status(400).json({error:'Выбери существующий раздел.'});
  if(title.length<5||title.length>90)return res.status(400).json({error:'Заголовок должен содержать от 5 до 90 символов.'});
  if(body.length<8||body.length>8000)return res.status(400).json({error:'Текст темы должен содержать от 8 до 8000 символов.'});
  const now=nowIso();const result=db.prepare('INSERT INTO topics(category_id,author_id,title,body,created_at,updated_at) VALUES(?,?,?,?,?,?)').run(category,req.user.id,title,body,now,now);
  audit(req.user.id,'topic.create','topic',result.lastInsertRowid,{category,title});
  res.status(201).json({ok:true,id:Number(result.lastInsertRowid)});
});
app.post('/api/topics/:id/replies',requireForumPosting,(req,res)=>{
  const id=Number(req.params.id);const topic=db.prepare('SELECT * FROM topics WHERE id=?').get(id);if(!topic)return res.status(404).json({error:'Тема не найдена.'});
  if(topic.locked&&!hasPermission(req.user.role,'forum.moderate'))return res.status(403).json({error:'Тема закрыта для ответов.'});
  const body=String(req.body.body||'').trim();if(body.length<2||body.length>4000)return res.status(400).json({error:'Ответ должен содержать от 2 до 4000 символов.'});
  const result=db.prepare('INSERT INTO replies(topic_id,author_id,body,created_at) VALUES(?,?,?,?)').run(id,req.user.id,body,nowIso());
  db.prepare('UPDATE topics SET updated_at=? WHERE id=?').run(nowIso(),id);
  if (topic.author_id !== req.user.id) createNotification(topic.author_id,'reply','Новый ответ в твоей теме',`${req.user.display_name} ответил(а): ${body.slice(0,180)}`,`/#topic-${id}`);
  res.status(201).json({ok:true,id:Number(result.lastInsertRowid)});
});
app.post('/api/topics/:id/like',requireForumPosting,(req,res)=>{
  const id=Number(req.params.id);if(!db.prepare('SELECT id FROM topics WHERE id=?').get(id))return res.status(404).json({error:'Тема не найдена.'});
  const exists=db.prepare('SELECT 1 FROM topic_likes WHERE topic_id=? AND user_id=?').get(id,req.user.id);
  if(exists)db.prepare('DELETE FROM topic_likes WHERE topic_id=? AND user_id=?').run(id,req.user.id);
  else {
    db.prepare('INSERT INTO topic_likes(topic_id,user_id,created_at) VALUES(?,?,?)').run(id,req.user.id,nowIso());
    const topicOwner=db.prepare('SELECT author_id,title FROM topics WHERE id=?').get(id);
    if(topicOwner && topicOwner.author_id !== req.user.id) createNotification(topicOwner.author_id,'like','Кому-то понравилась твоя тема',`${req.user.display_name} оценил(а) тему «${topicOwner.title}».`,`/#topic-${id}`);
  }
  const likes=db.prepare('SELECT COUNT(*) AS count FROM topic_likes WHERE topic_id=?').get(id).count;
  res.json({liked:!exists,likes});
});
app.post('/api/topics/:id/moderate',requirePermission('forum.moderate'),(req,res)=>{
  const id=Number(req.params.id);const topic=db.prepare('SELECT * FROM topics WHERE id=?').get(id);if(!topic)return res.status(404).json({error:'Тема не найдена.'});
  const updates=[];const values=[];
  for(const key of ['pinned','locked'])if(typeof req.body[key]==='boolean'){
    const permission=key==='pinned'?'forum.pin':'forum.lock';if(!hasPermission(req.user.role,permission))return res.status(403).json({error:'Нет разрешения на изменение этого параметра.'});
    updates.push(`${key}=?`);values.push(req.body[key]?1:0);
  }
  if(!updates.length)return res.status(400).json({error:'Нет изменений для сохранения.'});
  values.push(id);db.prepare(`UPDATE topics SET ${updates.join(',')},updated_at=? WHERE id=?`).run(...values.slice(0,-1),nowIso(),id);
  audit(req.user.id,'topic.moderate','topic',id,req.body);res.json({ok:true});
});
app.delete('/api/topics/:id',requirePermission('forum.delete'),(req,res)=>{
  const id=Number(req.params.id);const result=db.prepare('DELETE FROM topics WHERE id=?').run(id);if(!result.changes)return res.status(404).json({error:'Тема не найдена.'});audit(req.user.id,'topic.delete','topic',id);res.json({ok:true});
});

app.put('/api/profile',requireAuth,(req,res)=>{
  const displayName=String(req.body.displayName||'').trim().replace(/\s+/g,' '),bio=String(req.body.bio||'').trim(),signature=String(req.body.signature||'').trim(),avatarUrl=String(req.body.avatarUrl||'').trim(),accent=String(req.body.accent||'red');
  if(displayName.length<2||displayName.length>32)return res.status(400).json({error:'Ник должен быть длиной от 2 до 32 символов.'});
  if(bio.length>220||signature.length>100)return res.status(400).json({error:'Описание или подпись слишком длинные.'});
  if(avatarUrl&&(!/^https:\/\//i.test(avatarUrl)||avatarUrl.length>500))return res.status(400).json({error:'Аватар должен быть HTTPS-ссылкой длиной до 500 символов.'});
  if(!['red','green','blue','purple','orange'].includes(accent))return res.status(400).json({error:'Неизвестная тема профиля.'});
  const emailNotifications = req.body.emailNotifications === false ? 0 : 1;
  db.prepare('UPDATE users SET display_name=?,bio=?,signature=?,avatar_url=?,accent=?,email_notifications=? WHERE id=?').run(displayName,bio,signature,avatarUrl,accent,emailNotifications,req.user.id);
  res.json({ok:true,user:safeUser(getUserById.get(req.user.id))});
});
app.get('/api/team',(_req,res)=>{
  const rows=db.prepare(`SELECT u.* FROM users u JOIN roles r ON r.role_key=u.role WHERE u.role!='player' AND u.role NOT IN ('verified','muted','banned') ORDER BY r.rank DESC,u.display_name COLLATE NOCASE`).all();
  res.json({team:rows.map(row=>{const member=safeUser(row);delete member.email;delete member.emailVerifiedAt;delete member.emailNotifications;return member;})});
});
app.get('/api/servers',async(_req,res)=>{
  if(!GAME_STATUS_API_URL)return res.json({configured:false,available:false,servers:[],message:'Источник статуса игровых серверов не подключён.'});
  try{
    const response=await fetch(GAME_STATUS_API_URL,{headers:{accept:'application/json'},signal:AbortSignal.timeout(3500)});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    const payload=await response.json();const raw=Array.isArray(payload)?payload:(Array.isArray(payload.servers)?payload.servers:[]);
    const servers=raw.slice(0,30).map((item,index)=>({name:String(item.name||`Сервер ${index+1}`).slice(0,80),online:Boolean(item.online),players:Math.max(0,Number(item.players)||0),maxPlayers:Math.max(0,Number(item.maxPlayers)||0),map:String(item.map||'').slice(0,50)}));
    res.json({configured:true,available:true,servers,message:''});
  }catch(error){console.error('[game status api]',error.message);res.json({configured:true,available:false,servers:[],message:'Источник подключён, но сейчас не отвечает.'});}
});

const roleSummary=role=>({id:role.id,key:role.role_key,label:role.label,description:role.description,color:role.color,rank:role.rank,isSystem:Boolean(role.is_system)});
app.get('/api/roles',(_req,res)=>res.json({roles:db.prepare('SELECT * FROM roles ORDER BY rank DESC,label').all().map(roleSummary)}));
app.get('/api/admin/overview',requirePermission('admin.view'),(_req,res)=>{
  const members=db.prepare('SELECT COUNT(*) AS count FROM users').get().count;
  const online=db.prepare('SELECT COUNT(*) AS count FROM users WHERE last_seen_at>=? AND (banned_until IS NULL OR banned_until<=?)').get(new Date(Date.now()-90_000).toISOString(),Date.now()).count;
  const topics=db.prepare('SELECT COUNT(*) AS count FROM topics').get().count;
  const replies=db.prepare('SELECT COUNT(*) AS count FROM replies').get().count;
  const active7d=db.prepare('SELECT COUNT(*) AS count FROM users WHERE last_login_at>=?').get(new Date(Date.now()-7*86400000).toISOString()).count;
  const roleCounts=db.prepare('SELECT role,COUNT(*) AS count FROM users GROUP BY role').all();
  res.json({members,online,topics,posts:topics+replies,active7d,roleCounts,emailReady:Boolean(mailer),adminEmail:ADMIN_EMAIL,gameApiReady:Boolean(GAME_STATUS_API_URL)});
});
app.get('/api/admin/users',requirePermission('users.view'),(req,res)=>{
  const q=String(req.query.q||'').trim().slice(0,60);
  const rows=q?db.prepare('SELECT * FROM users WHERE display_name LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 150').all(`%${q}%`,`%${q}%`):db.prepare('SELECT * FROM users ORDER BY id DESC LIMIT 150').all();
  res.json({users:rows.map(safeUser)});
});
app.post('/api/admin/users/:id/role',requirePermission('users.assign_role'),(req,res)=>{
  const id=Number(req.params.id),target=getUserById.get(id);if(!target)return res.status(404).json({error:'Пользователь не найден.'});
  if(target.role==='owner')return res.status(403).json({error:'Роль владельца защищена и не меняется из админки.'});
  const roleKey=String(req.body.role||'');const role=roleByKey.get(roleKey);if(!role)return res.status(400).json({error:'Такой роли нет.'});
  if(roleKey==='owner')return res.status(403).json({error:'Назначить владельца таким способом нельзя.'});
  if(req.user.role!=='owner'){
    const actorRole=roleByKey.get(req.user.role);if(role.rank>=actorRole.rank)return res.status(403).json({error:'Нельзя назначать роль равную или выше собственной.'});
  }
  db.prepare('UPDATE users SET role=? WHERE id=?').run(roleKey,id);audit(req.user.id,'user.role.assign','user',id,{role:roleKey});
  createNotification(id,'role','Твоя роль обновлена',`Администрация Love Russia назначила тебе роль «${role.label}».`,'/');
  res.json({ok:true,user:safeUser(getUserById.get(id))});
});
app.post('/api/admin/users/:id/ban',requirePermission('users.ban'),(req,res)=>{
  const id=Number(req.params.id),target=getUserById.get(id);if(!target)return res.status(404).json({error:'Пользователь не найден.'});
  if(target.role==='owner')return res.status(403).json({error:'Нельзя ограничить владельца проекта.'});
  const minutes=Math.max(1,Math.min(43200,Number(req.body.minutes)||60));const reason=String(req.body.reason||'').trim().slice(0,200);
  db.prepare('UPDATE users SET banned_until=?,ban_reason=? WHERE id=?').run(Date.now()+minutes*60000,reason,id);audit(req.user.id,'user.ban','user',id,{minutes,reason});
  createNotification(id,'moderation','На аккаунт наложено ограничение',`Срок: ${minutes} мин. Причина: ${reason || 'не указана'}.`,'/');res.json({ok:true});
});
app.delete('/api/admin/users/:id/ban',requirePermission('users.ban'),(req,res)=>{
  const id=Number(req.params.id),target=getUserById.get(id);if(!target)return res.status(404).json({error:'Пользователь не найден.'});if(target.role==='owner')return res.status(403).json({error:'Нельзя снять ограничения владельца.'});
  db.prepare("UPDATE users SET banned_until=NULL,ban_reason='' WHERE id=?").run(id);audit(req.user.id,'user.unban','user',id);
  createNotification(id,'moderation','Ограничение снято','Администрация сняла ограничение с твоего аккаунта.','/');res.json({ok:true});
});
app.get('/api/admin/roles',requireOwner,(_req,res)=>{
  const rows=db.prepare(`SELECT r.*,(SELECT COUNT(*) FROM users u WHERE u.role=r.role_key) AS users_count FROM roles r ORDER BY r.rank DESC,r.label`).all();
  res.json({roles:rows.map(row=>({...roleSummary(row),permissions:JSON.parse(row.permissions_json),usersCount:row.users_count})),permissionOptions:permissionOptions.map(([key,label])=>({key,label}))});
});
app.post('/api/admin/roles',requireOwner,(req,res)=>{
  const label=String(req.body.label||'').trim(),description=String(req.body.description||'').trim().slice(0,180),color=String(req.body.color||'#b0b8c0'),rank=Math.min(700,Math.max(1,Number(req.body.rank)||100));
  if(label.length<2||label.length>40)return res.status(400).json({error:'Название роли должно содержать от 2 до 40 символов.'});
  if(!/^#[0-9a-fA-F]{6}$/.test(color))return res.status(400).json({error:'Укажи корректный HEX-цвет.'});
  const requestedBase=String(req.body.key||label.toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')).replace(/[^a-z0-9_]/gi,'').toLowerCase().slice(0,24);
  const base=requestedBase||`role_${Date.now().toString(36)}`;
  if(['owner','player','admin'].includes(base))return res.status(400).json({error:'Такой ключ роли использовать нельзя.'});
  const key=`custom_${base}`;const permissions=Array.isArray(req.body.permissions)?[...new Set(req.body.permissions.filter(p=>allPermissions.has(p)))]:[];
  try{const result=db.prepare('INSERT INTO roles(role_key,label,description,color,permissions_json,rank,is_system,created_at) VALUES(?,?,?,?,?,?,0,?)').run(key,label,description,color,JSON.stringify(permissions),rank,nowIso());audit(req.user.id,'role.create','role',result.lastInsertRowid,{key,label,permissions});res.status(201).json({ok:true,key});}
  catch(error){if(String(error.message).includes('UNIQUE'))return res.status(409).json({error:'Роль с таким ключом уже существует.'});throw error;}
});
app.put('/api/admin/roles/:id',requireOwner,(req,res)=>{
  const id=Number(req.params.id),role=db.prepare('SELECT * FROM roles WHERE id=?').get(id);if(!role)return res.status(404).json({error:'Роль не найдена.'});if(role.is_system)return res.status(403).json({error:'Системные роли защищены. Создай отдельную пользовательскую роль.'});
  const label=String(req.body.label||'').trim(),description=String(req.body.description||'').trim().slice(0,180),color=String(req.body.color||role.color),rank=Math.min(700,Math.max(1,Number(req.body.rank)||role.rank));
  if(label.length<2||label.length>40)return res.status(400).json({error:'Название роли должно содержать от 2 до 40 символов.'});if(!/^#[0-9a-fA-F]{6}$/.test(color))return res.status(400).json({error:'Укажи корректный HEX-цвет.'});
  const permissions=Array.isArray(req.body.permissions)?[...new Set(req.body.permissions.filter(p=>allPermissions.has(p)))]:[];
  db.prepare('UPDATE roles SET label=?,description=?,color=?,rank=?,permissions_json=? WHERE id=?').run(label,description,color,rank,JSON.stringify(permissions),id);audit(req.user.id,'role.update','role',id,{label,permissions});res.json({ok:true});
});
app.delete('/api/admin/roles/:id',requireOwner,(req,res)=>{
  const id=Number(req.params.id),role=db.prepare('SELECT * FROM roles WHERE id=?').get(id);if(!role)return res.status(404).json({error:'Роль не найдена.'});if(role.is_system)return res.status(403).json({error:'Системные роли нельзя удалить.'});
  const assigned=db.prepare('SELECT COUNT(*) AS count FROM users WHERE role=?').get(role.role_key).count;if(assigned)return res.status(409).json({error:`Эта роль назначена ${assigned} пользователям. Сначала переназначь их.`});
  db.prepare('DELETE FROM roles WHERE id=?').run(id);audit(req.user.id,'role.delete','role',id,{key:role.role_key});res.json({ok:true});
});
app.post('/api/admin/notifications/broadcast',requireOwner,(req,res)=>{
  const title=String(req.body.title||'').trim().slice(0,100),body=String(req.body.body||'').trim().slice(0,1000);
  if(title.length<3||body.length<3)return res.status(400).json({error:'Укажи заголовок и текст объявления.'});
  const recipients=db.prepare('SELECT id FROM users').all();
  const insert=db.prepare('INSERT INTO notifications(user_id,type,title,body,link,created_at) VALUES(?,?,?,?,?,?)');
  const created=nowIso();
  const tx=db.transaction(()=>{for(const recipient of recipients)insert.run(recipient.id,'announcement',title,body,'/',created);});
  tx();audit(req.user.id,'notification.broadcast','users',recipients.length,{title});
  res.json({ok:true,recipients:recipients.length});
});

app.get('/api/admin/audit',requireOwner,(req,res)=>{
  const rows=db.prepare(`SELECT a.*,u.display_name AS actor_name FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 100`).all();
  res.json({logs:rows.map(row=>({...row,details:JSON.parse(row.details_json)}))});
});

app.get('/',(_req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.use(express.static(path.join(__dirname,'public'),{dotfiles:'deny',index:false,maxAge:IS_PROD?'1h':0}));
app.use((req,res)=>{if(req.path.startsWith('/api/'))return res.status(404).json({error:'API route not found'});res.status(404).send('Страница не найдена. <a href="/">На главную</a>');});
app.use((error,_req,res,_next)=>{console.error('[server error]',error);res.status(500).json({error:'Внутренняя ошибка сервера. Посмотри журнал сервера.'});});

const server=app.listen(PORT,()=>{
  console.log(`Love Russia Forum v5: ${PUBLIC_URL}`);
  console.log(`Database: ${path.join(dataDir,'love-russia.sqlite')}`);
  console.log(`Email authentication: ${mailer ? 'SMTP configured' : 'NOT CONFIGURED — set SMTP_HOST, SMTP_USER and SMTP_PASS in .env'}`);
  console.log(`Admin email: ${ADMIN_EMAIL}`);
  console.log(`Game status API: ${GAME_STATUS_API_URL?'configured':'not configured; no fake player counts will be shown'}`);
});
process.on('SIGINT',()=>{server.close(()=>{db.close();process.exit(0);});});
process.on('SIGTERM',()=>{server.close(()=>{db.close();process.exit(0);});});
