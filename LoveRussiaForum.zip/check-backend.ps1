$ErrorActionPreference = 'Stop'
$base = 'http://localhost:3000'
Write-Host 'Проверка backend Love Russia...' -ForegroundColor Red
try {
    $health = Invoke-RestMethod -Uri "$base/api/health" -TimeoutSec 5
    $config = Invoke-RestMethod -Uri "$base/api/config" -TimeoutSec 5
    Write-Host "Backend: OK ($($health.service), v$($health.version))" -ForegroundColor Green
    Write-Host "База данных: $($health.database)"
    Write-Host "Email SMTP: $(if ($config.auth.email) {'НАСТРОЕН'} else {'НЕ НАСТРОЕН'})"
    Write-Host "Уведомления: $(if ($config.notifications) {'включены'} else {'выключены'})"
    Write-Host "Адрес сайта: $($config.publicUrl)"
    if (-not $config.auth.email) {
        Write-Host 'Регистрация не отправит коды, пока SMTP_PASS и остальные SMTP-параметры не заполнены в .env.' -ForegroundColor Yellow
    }
} catch {
    Write-Host 'Backend НЕ доступен на http://localhost:3000.' -ForegroundColor Red
    Write-Host 'Запусти .\start.ps1 в корне архива и открой http://localhost:3000.'
    exit 1
}
