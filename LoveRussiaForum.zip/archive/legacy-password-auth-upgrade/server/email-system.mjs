import express from "express";
import crypto from "node:crypto";
import { promisify } from "node:util";
import nodemailer from "nodemailer";
import rateLimit from "express-rate-limit";

const scrypt = promisify(crypto.scrypt);
const sha256 = value => crypto.createHash("sha256").update(value).digest("hex");
const randomToken = () => crypto.randomBytes(32).toString("base64url");
const normalizeEmail = value => String(value || "").trim().toLowerCase();
const safeEqual = (a, b) => {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
};

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = await scrypt(password, salt, 64);
  return `scrypt$${salt}$${Buffer.from(derived).toString("hex")}`;
}
async function verifyPassword(password, stored) {
  if (typeof stored !== "string") return false;
  const [kind, salt, hash] = stored.split("$");
  if (kind !== "scrypt" || !salt || !hash) return false;
  const derived = await scrypt(password, salt, 64);
  return safeEqual(Buffer.from(derived).toString("hex"), hash);
}

function makeMailer(env) {
  if (!env.SMTP_HOST || !env.SMTP_PORT || !env.SMTP_USER || !env.SMTP_PASS || !env.MAIL_FROM) {
    return null;
  }
  return nodemailer.createTransport({
    host: env.SMTP_HOST,
    port: Number(env.SMTP_PORT),
    secure: String(env.SMTP_SECURE || "false") === "true",
    auth: { user: env.SMTP_USER, pass: env.SMTP_PASS }
  });
}

/**
 * Mount with:
 * app.use("/api/email", createEmailRouter({
 *   db, env: process.env,
 *   setSessionUser: async (req, user) => { req.session.userId = user.id; },
 *   getSessionUserId: req => req.session?.userId,
 *   audit: (actorId, action, targetId, details) => audit(...)
 * }));
 *
 * Adapt setSessionUser/getSessionUserId to the session shape already used by
 * the forum. This module deliberately does not replace Telegram/VK sessions.
 */
export function createEmailRouter({
  db, env = process.env, setSessionUser, getSessionUserId,
  audit = () => {}, publicUrl = env.PUBLIC_URL || "http://localhost:3000"
}) {
  if (!db) throw new Error("createEmailRouter requires the existing SQLite db");
  if (typeof setSessionUser !== "function" || typeof getSessionUserId !== "function") {
    throw new Error("Provide setSessionUser and getSessionUserId adapters for the existing session format");
  }

  // SQLite has no ADD COLUMN IF NOT EXISTS, so inspect the current schema first.
  const columns = db.prepare("PRAGMA table_info(users)").all().map(c => c.name);
  for (const [name, sql] of [
    ["email", "ALTER TABLE users ADD COLUMN email TEXT"],
    ["password_hash", "ALTER TABLE users ADD COLUMN password_hash TEXT"],
    ["email_verified_at", "ALTER TABLE users ADD COLUMN email_verified_at TEXT"],
    ["account_status", "ALTER TABLE users ADD COLUMN account_status TEXT NOT NULL DEFAULT 'active'"]
  ]) {
    if (!columns.includes(name)) db.exec(sql);
  }
  db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique
      ON users(email COLLATE NOCASE) WHERE email IS NOT NULL;
    CREATE TABLE IF NOT EXISTS email_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      token_type TEXT NOT NULL CHECK(token_type IN ('verify','reset','change_email')),
      payload_email TEXT,
      expires_at TEXT NOT NULL,
      consumed_at TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS email_tokens_user_type
      ON email_tokens(user_id, token_type, consumed_at);
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL DEFAULT '',
      link TEXT,
      read_at TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS notifications_user_created
      ON notifications(user_id, created_at DESC);
  `);

  const router = express.Router();
  const mailer = makeMailer(env);
  const from = env.MAIL_FROM || "Love Russia <no-reply@example.invalid>";
  const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: "draft-8", legacyHeaders: false });
  const sendLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 4, standardHeaders: "draft-8", legacyHeaders: false });

  const userByEmail = db.prepare("SELECT * FROM users WHERE email = ? COLLATE NOCASE");
  const insertToken = db.prepare(`
    INSERT INTO email_tokens(user_id, token_hash, token_type, payload_email, expires_at)
    VALUES (?, ?, ?, ?, ?)
  `);
  const consumeToken = db.prepare(`
    UPDATE email_tokens SET consumed_at = CURRENT_TIMESTAMP
    WHERE id = ? AND consumed_at IS NULL
  `);

  async function sendToken(user, type, recipient = user.email) {
    if (!mailer) throw new Error("Почтовый сервер не настроен. Обратитесь к администратору.");
    const token = randomToken();
    const expiry = new Date(Date.now() + (type === "reset" ? 30 : 60) * 60_000).toISOString();
    insertToken.run(user.id, sha256(token), type, recipient, expiry);
    const path = type === "reset" ? "/reset-password" : "/verify-email";
    const url = `${publicUrl.replace(/\/$/, "")}${path}?token=${encodeURIComponent(token)}`;
    const subject = type === "reset" ? "Восстановление пароля — Love Russia" : "Подтверждение Email — Love Russia";
    const action = type === "reset" ? "Сменить пароль" : "Подтвердить Email";
    await mailer.sendMail({
      from, to: recipient, subject,
      text: `${action}: ${url}\nСсылка действительна ${type === "reset" ? "30" : "60"} минут. Если вы не запрашивали это действие, проигнорируйте письмо.`,
      html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:28px;background:#101411;color:#fff;border-radius:16px"><h1 style="color:#ef4444">LOVE RUSSIA</h1><p>${action}</p><p><a href="${url}" style="display:inline-block;padding:13px 20px;background:#c92d3a;color:white;text-decoration:none;border-radius:9px">${action}</a></p><p style="color:#aaa">Ссылка действительна ограниченное время. Если вы не запрашивали это действие, проигнорируйте письмо.</p></div>`
    });
  }

  router.post("/register", authLimiter, async (req, res) => {
    try {
      const email = normalizeEmail(req.body?.email);
      const password = String(req.body?.password || "");
      const displayName = String(req.body?.displayName || "").trim().slice(0, 32);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Укажите корректный Email." });
      if (password.length < 10 || password.length > 200) return res.status(400).json({ error: "Пароль должен содержать от 10 до 200 символов." });
      if (displayName.length < 2) return res.status(400).json({ error: "Укажите игровой ник (не менее 2 символов)." });
      if (userByEmail.get(email)) return res.status(409).json({ error: "Этот Email уже зарегистрирован." });
      const passwordHash = await hashPassword(password);
      const result = db.prepare(`
        INSERT INTO users(display_name, role, email, password_hash, account_status, created_at)
        VALUES (?, 'player', ?, ?, 'active', CURRENT_TIMESTAMP)
      `).run(displayName, email, passwordHash);
      const user = db.prepare("SELECT id, email FROM users WHERE id = ?").get(result.lastInsertRowid);
      await sendToken(user, "verify");
      audit(user.id, "email.register", user.id, { email });
      return res.status(201).json({ ok: true, verificationRequired: true, message: "Аккаунт создан. Проверьте почту для подтверждения адреса." });
    } catch (error) {
      return res.status(503).json({ error: error.message || "Не удалось создать аккаунт." });
    }
  });

  router.post("/login", authLimiter, async (req, res) => {
    const email = normalizeEmail(req.body?.email);
    const password = String(req.body?.password || "");
    const user = userByEmail.get(email);
    if (!user || !user.password_hash || !(await verifyPassword(password, user.password_hash))) {
      return res.status(401).json({ error: "Неверный Email или пароль." });
    }
    if (user.account_status !== "active") return res.status(403).json({ error: "Вход в этот аккаунт временно ограничен." });
    if (!user.email_verified_at) return res.status(403).json({ error: "Сначала подтвердите Email. При необходимости запросите письмо повторно." });
    await new Promise((resolve, reject) => {
      if (!req.session?.regenerate) return resolve();
      req.session.regenerate(err => err ? reject(err) : resolve());
    });
    await setSessionUser(req, { id: user.id, email: user.email });
    db.prepare("UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?").run(user.id);
    audit(user.id, "email.login", user.id, {});
    return res.json({ ok: true });
  });

  router.post("/verify", authLimiter, (req, res) => {
    const token = String(req.body?.token || "");
    if (!token) return res.status(400).json({ error: "Ссылка подтверждения недействительна." });
    const row = db.prepare(`
      SELECT t.*, u.email FROM email_tokens t JOIN users u ON u.id=t.user_id
      WHERE t.token_hash=? AND t.token_type='verify' AND t.consumed_at IS NULL AND t.expires_at > ?
    `).get(sha256(token), new Date().toISOString());
    if (!row) return res.status(400).json({ error: "Ссылка истекла или уже использована." });
    const tx = db.transaction(() => {
      consumeToken.run(row.id);
      db.prepare("UPDATE users SET email_verified_at=CURRENT_TIMESTAMP WHERE id=?").run(row.user_id);
    });
    tx();
    audit(row.user_id, "email.verified", row.user_id, {});
    return res.json({ ok: true, message: "Email подтверждён." });
  });

  router.post("/resend-verification", sendLimiter, async (req, res) => {
    const email = normalizeEmail(req.body?.email);
    const user = userByEmail.get(email);
    if (user && !user.email_verified_at && user.password_hash) {
      try { await sendToken(user, "verify"); } catch {}
    }
    return res.json({ ok: true, message: "Если аккаунт ожидает подтверждения, письмо будет отправлено." });
  });

  router.post("/forgot-password", sendLimiter, async (req, res) => {
    const email = normalizeEmail(req.body?.email);
    const user = userByEmail.get(email);
    if (user?.password_hash && user.email_verified_at && user.account_status === "active") {
      try { await sendToken(user, "reset"); } catch {}
    }
    return res.json({ ok: true, message: "Если аккаунт существует, на него будет отправлено письмо с дальнейшими инструкциями." });
  });

  router.post("/reset-password", authLimiter, async (req, res) => {
    const token = String(req.body?.token || "");
    const password = String(req.body?.password || "");
    if (password.length < 10 || password.length > 200) return res.status(400).json({ error: "Пароль должен содержать от 10 до 200 символов." });
    const row = db.prepare(`
      SELECT * FROM email_tokens
      WHERE token_hash=? AND token_type='reset' AND consumed_at IS NULL AND expires_at > ?
    `).get(sha256(token), new Date().toISOString());
    if (!row) return res.status(400).json({ error: "Ссылка истекла или уже использована." });
    const passwordHash = await hashPassword(password);
    const tx = db.transaction(() => {
      consumeToken.run(row.id);
      db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(passwordHash, row.user_id);
    });
    tx();
    audit(row.user_id, "email.password_reset", row.user_id, {});
    return res.json({ ok: true, message: "Пароль изменён. Теперь можно войти." });
  });

  router.get("/me", (req, res) => {
    const id = getSessionUserId(req);
    if (!id) return res.status(401).json({ error: "Требуется вход." });
    const user = db.prepare("SELECT id,email,email_verified_at,account_status FROM users WHERE id=?").get(id);
    if (!user) return res.status(401).json({ error: "Аккаунт не найден." });
    return res.json({ email: user.email, emailVerified: Boolean(user.email_verified_at), accountStatus: user.account_status });
  });

  router.get("/notifications", (req, res) => {
    const id = getSessionUserId(req);
    if (!id) return res.status(401).json({ error: "Требуется вход." });
    const items = db.prepare("SELECT id,type,title,body,link,read_at,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50").all(id);
    const unread = db.prepare("SELECT COUNT(*) AS count FROM notifications WHERE user_id=? AND read_at IS NULL").get(id).count;
    return res.json({ items, unread });
  });

  router.post("/notifications/:id/read", (req, res) => {
    const id = getSessionUserId(req);
    if (!id) return res.status(401).json({ error: "Требуется вход." });
    const result = db.prepare("UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?").run(Number(req.params.id), id);
    return res.json({ ok: result.changes > 0 });
  });

  return router;
}
