LOVE RUSSIA 5.0 — EMAIL/AUTH FOUNDATION

This is an additive feature pack, not a blind replacement of the existing forum.

Contents:
- server/email-system.mjs: Email registration/login, verification, password reset,
  account email status, notifications API.
- public/love-russia-5-auth.html: markup to add inside the existing login modal.
- public/love-russia-5-auth.js: browser logic.
- public/love-russia-5-auth.css: isolated styles.
- server/migration.sql: reference schema.

IMPORTANT INTEGRATION NOTES
1. Back up the entire project and SQLite database first.
2. Install Nodemailer: npm install nodemailer
3. The server module exports createEmailRouter({ db, env, setSessionUser,
   getSessionUserId, audit, publicUrl }).
4. In server.mjs, after the existing SQLite db and session middleware are ready,
   import:
     import { createEmailRouter } from "./server/email-system.mjs";
   Then mount:
     app.use("/api/email", createEmailRouter({
       db,
       env: process.env,
       setSessionUser: async (req, user) => { req.session.userId = user.id; },
       getSessionUserId: req => req.session?.userId,
       audit
     }));
   IMPORTANT: adapt these two session callbacks to the actual session format used
   by your existing server. Do not assume req.session.userId unless verified.
5. Do not run migration.sql blindly. The module performs guarded additive
   migrations itself. Existing users and identities are not deleted.
6. Add SMTP values to .env using your email provider's SMTP settings:
   SMTP_HOST=
   SMTP_PORT=587
   SMTP_SECURE=false
   SMTP_USER=
   SMTP_PASS=
   MAIL_FROM=
   PUBLIC_URL=https://your-real-domain
   Never share .env or SMTP credentials in chat.
7. Add the HTML block inside the existing login modal, then include the JS and CSS
   in index.html after the existing app stylesheet/script as appropriate.
8. Existing Telegram/VK login remains separate. Do not link accounts automatically
   merely because their email strings match.
9. This pack does not yet implement admin account controls, email-change workflow,
   profile themes/covers/achievements, notification preferences, or UI routing for
   password-reset pages. Those need integration against the actual admin/profile
   DOM and server permission model.

SECURITY REVIEW BEFORE PUBLIC DEPLOYMENT
- Configure HTTPS and a real SMTP sender.
- Set correct sameSite/secure session cookie policy.
- Review existing CSRF/origin middleware for these routes.
- Adapt session callbacks to the real server.
- Password reset does not yet revoke all existing sessions. Integrate session
  revocation using the host server's actual session store and serialization
  format before public deployment.
- Add CAPTCHA or stronger abuse controls if public registration is attacked.
- Ensure email sender domain has SPF, DKIM and DMARC.
