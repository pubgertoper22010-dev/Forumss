(() => {
  const form = document.getElementById("lr5EmailForm");
  if (!form || form.dataset.ready) return;
  form.dataset.ready = "1";
  const message = document.getElementById("lr5AuthMessage");
  const submit = document.getElementById("lr5EmailSubmit");
  const forgot = document.getElementById("lr5Forgot");
  let mode = "login";

  const show = text => { message.textContent = text; };
  const request = async (path, body) => {
    const response = await fetch(`/api/email/${path}`, {
      method: "POST", credentials: "same-origin",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Не удалось выполнить запрос.");
    return data;
  };

  document.querySelectorAll("[data-lr5-tab]").forEach(button => {
    button.addEventListener("click", () => {
      mode = button.dataset.lr5Tab;
      document.querySelectorAll("[data-lr5-tab]").forEach(item => item.classList.toggle("is-active", item === button));
      const register = mode === "register";
      form.querySelectorAll("[data-register-only]").forEach(item => {
        item.closest("label").hidden = !register;
        item.required = register;
      });
      form.elements.password.autocomplete = register ? "new-password" : "current-password";
      submit.textContent = register ? "Создать аккаунт" : "Войти";
      forgot.hidden = register;
      show("");
    });
  });

  form.addEventListener("submit", async event => {
    event.preventDefault();
    submit.disabled = true;
    try {
      const body = Object.fromEntries(new FormData(form).entries());
      const result = await request(mode, body);
      show(result.message || (mode === "login" ? "Вход выполнен. Обновите страницу." : "Проверьте почту для подтверждения."));
      if (mode === "login") setTimeout(() => location.reload(), 700);
    } catch (error) { show(error.message); }
    finally { submit.disabled = false; }
  });

  forgot?.addEventListener("click", async () => {
    const email = form.elements.email.value.trim();
    if (!email) return show("Сначала укажите Email.");
    try {
      const result = await request("forgot-password", { email });
      show(result.message);
    } catch (error) { show(error.message); }
  });

  const token = new URLSearchParams(location.search).get("token");
  if (token && location.pathname.endsWith("/verify-email")) {
    request("verify", { token }).then(result => show(result.message)).catch(error => show(error.message));
  }
})();
